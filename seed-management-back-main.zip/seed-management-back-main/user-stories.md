# WEB BASED SYSTEM OF SAN JORGE MUNICIPAL AGRICULTURE OFFICE

### Roles

1. Users account roles

-   Rice officer
-   High-crop value officer
-   Corn officer

> Same features for all roles

2. Generate Automated Registration id with QR code to remove duplication

3. To perform accounting operations in terms of seeds distribution

    - officer can decide to distribute seeds

4. To generate reports

### User Stories

> All officer roles

-   [x] Login

-   Farmers

    -   [x] List of Farmers
    -   [x] Register farmer

        -   [x] Farmer's data is based on RSBSA form
        -   [x] Upload RSBSA form, tax declaration, brgy. clearance, insurance, valid id's, stab and client satisfaction
        -   [x] Generate QR code for farmer with full name

    -   [x] View farmer's data

        -   [x] Display farmer's data
        -   [x] Display farmer's QR code
        -   [ ] View all records of farmer including benefits, etc.

    -   [x] Update farmer's data
    -   [x] Delete Farmer

-   Lands

    -   [x] Display all Lands
    -   [x] View Land Details

-   Barangays

    -   [x] Display all Barangays
    -   [x] Edit/Update Barangay
    -   [x] Delete Barangay

-   Accounting

    -   Rice Distribution
        -   [x] Display all rice distribution
        -   [ ] All farmers from the list from region
        -   [ ] Only for rice officer
        -   [ ] Add new Distribution
            -   Title
            -   Guidelines / Requirements
            -   List of farmers
            -   Officer can put a reason for farmer
    -   Seeds Distribution

        -   [x] Display all seeds distribution
        -   [ ] Only for High-value crops officer and Corn officer
        -   [ ] Add new distribution

            -   [ ] Issues slip from region with multiple seeds
                -   Seed
                    -   Qty: 10
                    -   Unit: 100grams
                -   Type of seed / Article, ex: Eggplant, Okra etc.
            -   [ ] Select farmers / Beneficiaries
                -   Search farmer using QR or Id number
            -   [ ] Attach new client satisfaction form with number

        -   [ ] View distribution
            -   [ ] Display all details of distribution
            -   [ ] Farmer Client Satisfaction
            -   [ ] Upload copy of client satisfaction feedback (optional)
            -   [ ] Satisfied / Unsatisfied (required)
            -   [ ] Seed (required)
                -   Qty: 10
                -   Unit: 100grams

    -   Financial Distribution
        -   [x] Display all financial distribution
        -   [ ] All officers have access
        -   [ ] Add , view
        -   [ ] Two types of financial distribution
            -   With Insurance
            -   Without Insurance

-   ADMIN

    -   [x] Login
    -   [x] Add officer account
    -   [x] Add Roles
    -   [x] Update Roles and Permissions

1.  Home page must display a SCHEDULE OF ACTIVITIES. (purpose para ang mga farmers makita ang announcement, schedule of activities tulad ng date seeds releasing and etc.)
    FARMERS – maka view
    ADMIN AT OFFICERS – maka post

2.  DONE - Change to HVC Distribution

3.  Sa REGISTER NEW FARMER, add CATEGORY OF FARMER
    Category A - 3 Crop/Commodity (bali mayda hiya Rice, HVC and Corn)
    Category B -2 Crop/Commodity ( bali duha )
    Category C – 1 Crop/Commodity ( usa la)
    Note: ang reference ni sir ang RSBSA Form sa back page

4.  Measurement mayda UNIT HECTARE,

    seed type change to CROP/COMMODITY ang dropdown Rice, Corn, High Value Crops

5.  Sample data of dummy account must correct input data
6.  ID must be based on RSBSA reference no. Ex. 08-60-25-03-00002

7.  Pag scan ng QR Code dapat mag display ang RSBSA ID, FULL NAME, Category of Farmer ( A, B, C), previous benefits claim and possible benefits depende sa iya category.

8.  Generate report: MASTER LIST OF FARMERS (dapat pwede ma filter),

9.  Generate report: BALANCE SHEET REPORT (reports han mga releasing / distribution) , dapat mag match ang amount of SEEDS RELEASE BY REGION sa amount of seeds na GIN DISTRIBUTE ni officer. Kung diri mag match dapat mag RED COLOR or NOTIFICATION na ito na specific na seeds diri match.

10. Sa high value crops dapat naka indicate ang seeds eggplant, okra, hot pepper, lettuce (head), lettuce (leafy), pechay, sweetpepper, tomato, ampalaya at squash.

11. Ang CLIENT SATISFACTION FEEDBACK dapat makita sa system na input data dahil anxa ang magiging basis sa accounting operation which mag check kung mag match ang quantity han seeds by the region at municipal.
