const defaultTheme = require("tailwindcss/defaultTheme")
module.exports = {
    content: [
        "./resources/**/*.{js,jsx,ts,tsx}",
        "./node_modules/flowbite/**/*.js",
    ],
    darkMode: "class",
    theme: {
        extend: {
            colors: {
                primary: {
                    50: "#f4f9f0",
                    100: "#e5efdc",
                    200: "#cadfbb",
                    300: "#a2c78e",
                    400: "#75a95e",
                    500: "#538d3c",
                    600: "#3c702b",
                    700: "#2f5a22",
                    800: "#27481d",
                    900: "#1f3918",
                },
            },
            fontFamily: {
                sans: ["Inter var", ...defaultTheme.fontFamily.sans],
            },
        },
    },
    plugins: [require("flowbite/plugin")],
}
