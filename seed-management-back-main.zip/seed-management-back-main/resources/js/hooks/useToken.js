import React, { useState } from "react"

const useToken = () => {
    const getToken = () => {
        return localStorage.getItem("token")
    }

    const [token, setToken] = useState(getToken())
    const saveToken = tokenString => {
        localStorage.setItem("token", tokenString)
        setToken(tokenString)
    }
    return {
        token,
        setToken: saveToken,
    }
}

export default useToken
