import React from "react"
import PropTypes from "prop-types"

const Input = ({ name, type, label, register, errors }) => {
    return (
        <>
            <label
                for={name}
                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            >
                {label}
            </label>
            <input
                {...register(name)}
                name={name}
                type={type}
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            />

            <p class="text-red-500 text-xs font-normal mt-1 first-letter:uppercase">
                {errors && errors[name]?.message.replaceAll("_", " ")}
            </p>
        </>
    )
}

Input.defaultProps = {
    type: "text",
    label: "Input Sample",
    errors: [],
}

Input.propTypes = {
    name: PropTypes.string.isRequired,
    type: PropTypes.string,
    label: PropTypes.string.isRequired,
    register: PropTypes.func.isRequired,
}

export default Input
