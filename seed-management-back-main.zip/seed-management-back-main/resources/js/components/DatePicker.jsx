import React, { useEffect } from "react"
import PropTypes from "prop-types"
import Datepicker from "flowbite-datepicker/Datepicker"
const DatePicker = ({ id, name, label, register, errors }) => {
    useEffect(() => {
        const datePicker = document?.getElementById(`${id}`)
        new Datepicker(datePicker, {})
    }, [])

    return (
        <>
            <label
                for={name}
                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            >
                {label}
            </label>
            <div class="relative">
                <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <svg
                        aria-hidden="true"
                        class="w-5 h-5 text-gray-500 dark:text-gray-400"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg"
                    >
                        <path
                            fill-rule="evenodd"
                            d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z"
                            clip-rule="evenodd"
                        ></path>
                    </svg>
                </div>
                <input
                    {...register(name)}
                    datepicker
                    datepicker-autohide
                    type="text"
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Select date"
                    onSelect={e => console.log(e.target.value)}
                    id={id}
                />
            </div>
            <p class="text-red-500 text-xs font-normal mt-1 first-letter:uppercase">
                {errors && errors[name]?.message.replaceAll("_", " ")}
            </p>
        </>
    )
}

DatePicker.defaultProps = {
    label: "DatePicker Sample",
    errors: [],
}

DatePicker.propTypes = {
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    register: PropTypes.func.isRequired,
}

export default DatePicker
