import React, { useEffect, useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import PropTypes from "prop-types"
import ReactPaginate from "react-paginate"
import { Modal } from "flowbite"

const TableHeader = ({ caption, addNew, onFilter }) => {
    const navigate = useNavigate()

    // filter feature
    const [search, setSearch] = useState()
    const [timer, setTimer] = useState(null)

    const handleFilter = e => {
        setSearch(e.target.value)
        clearTimeout(timer)
        const newTimer = setTimeout(() => {
            onFilter({ search: e.target.value })
        }, 800)

        setTimer(newTimer)
    }

    const handleAddNewRedirect = () => {
        if (typeof addNew != "string" && typeof addNew != "function") {
            console.error("Invalid type, please pass string or function")
            return
        }

        if (typeof addNew == "string") {
            navigate(addNew)
        } else {
            addNew()
        }
    }
    return (
        <>
            <caption className="relative block mb-5 text-lg font-semibold text-left text-gray-900 bg-white dark:text-white dark:bg-inherit">
                {caption}
            </caption>
            <div className="flex justify-between flex-col gap-5 items-start md:flex-row pb-4 bg-white dark:bg-inherit">
                <div className="relative">
                    <div className="flex absolute inset-y-0 left-0 items-center pl-3 pointer-events-none">
                        <svg
                            className="w-5 h-5 text-gray-500 dark:text-gray-400"
                            aria-hidden="true"
                            fill="currentColor"
                            viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                fillRule="evenodd"
                                d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                                clipRule="evenodd"
                            ></path>
                        </svg>
                    </div>
                    <input
                        type="text"
                        id="table-search-users"
                        value={search || ""}
                        onChange={e => handleFilter(e)}
                        className="block p-2 pl-10 w-80 text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder={`Search for ${caption}`}
                    />
                </div>
                {addNew && (
                    <button
                        onClick={handleAddNewRedirect}
                        type="button"
                        className="text-white bg-primary-600 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800"
                    >
                        Add new {caption}
                    </button>
                )}
            </div>
        </>
    )
}

const TableHead = ({ headers }) => {
    return (
        <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
                {headers.map((head, index) => (
                    <th key={index} scope="col" className="px-6 py-3">
                        {head.text}
                    </th>
                ))}
            </tr>
        </thead>
    )
}
TableHead.propTypes = {
    headers: PropTypes.array.isRequired,
}

const TableRow = ({
    item,
    headers,
    modal,
    routeRedirect,
    toggleView,
    toggleEdit,
    toggleDelete,
}) => {
    let formatted_item = {}
    headers.forEach((head, index) => {
        formatted_item[head.value] = item[head.value]
    })
    // format item classes
    const classes = headers.map(item => item.item_class)

    // show modal
    const toggleDeleteModal = () => {
        modal.show()
        toggleDelete(item)
    }

    return (
        <tr className="bg-gray-50 border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-white dark:hover:bg-gray-700">
            {Object.keys(formatted_item).map((itemKey, index) =>
                itemKey != "action" ? (
                    <td className={`px-6 py-4 ${classes[index]}`} key={index}>
                        {item[itemKey]}
                    </td>
                ) : (
                    <td
                        className="items-center py-4 px-6 space-x-3"
                        key={index}
                    >
                        {item.action?.view &&
                            (item.action.view == "redirect" ? (
                                <Link
                                    to={`${routeRedirect}/view/${item.id}`}
                                    className="font-medium w- text-blue-600 dark:text-blue-500 hover:underline"
                                >
                                    View
                                </Link>
                            ) : (
                                <a
                                    onClick={() => toggleView(item)}
                                    href="#"
                                    className="font-medium w- text-blue-600 dark:text-blue-500 hover:underline"
                                >
                                    View
                                </a>
                            ))}

                        {item.action?.edit &&
                            (item.action.edit == "redirect" ? (
                                <Link
                                    to={`${routeRedirect}/edit/${item.id}`}
                                    className="font-medium w- text-blue-600 dark:text-blue-500 hover:underline"
                                >
                                    Edit
                                </Link>
                            ) : (
                                <a
                                    onClick={() => toggleEdit(item)}
                                    href="#"
                                    className="font-medium w- text-blue-600 dark:text-blue-500 hover:underline"
                                >
                                    Edit
                                </a>
                            ))}
                        {item.action?.delete && (
                            <a
                                onClick={() => toggleDeleteModal(item)}
                                href="#"
                                className="font-medium text-red-600 dark:text-red-500 hover:underline"
                            >
                                Remove
                            </a>
                        )}
                    </td>
                )
            )}
        </tr>
    )
}

const DeleteModal = ({ item, onDelete, modal }) => {
    return (
        <div
            id="delete-modal"
            data-modal-target="delete-modal"
            tabIndex="-1"
            className="fixed top-0 left-0 right-0 z-50 hidden p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-modal md:h-full"
        >
            <div className="relative w-full h-full max-w-md md:h-auto">
                <div className="relative bg-white rounded-lg shadow dark:bg-gray-700">
                    <button
                        onClick={() => modal.hide()}
                        type="button"
                        className="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-800 dark:hover:text-white"
                        data-modal-hide="delete-modal"
                    >
                        <svg
                            aria-hidden="true"
                            className="w-5 h-5"
                            fill="currentColor"
                            viewBox="0 0 20 20"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                fillRule="evenodd"
                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                clipRule="evenodd"
                            ></path>
                        </svg>
                    </button>
                    <div className="p-6 text-center">
                        <svg
                            aria-hidden="true"
                            className="mx-auto mb-4 text-gray-400 w-14 h-14 dark:text-gray-200"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth="2"
                                d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                            ></path>
                        </svg>
                        <h3 className="mb-5 text-lg font-normal text-gray-500 dark:text-gray-400">
                            Are you sure you want to delete ?
                        </h3>
                        <button
                            onClick={() => onDelete(item)}
                            type="button"
                            className="text-white bg-red-600 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2"
                        >
                            Yes, I'm sure
                        </button>
                        <button
                            onClick={() => modal.hide()}
                            type="button"
                            className="text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600"
                        >
                            No, cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}

const Table = ({
    caption,
    addNew,
    items,
    headers,
    withActions,
    itemsPerPage,
    onFilter,
    routeRedirect,
    onView,
    onEdit,
    onDelete,
}) => {
    // Here we use item offsets; we could also use page offsets
    // following the API or data you're working with.
    const [itemOffset, setItemOffset] = useState(0)

    // Simulate fetching items from another resources.
    // (This could be items from props; or items loaded in a local state
    // from an API endpoint with useEffect and useState)
    const endOffset = itemOffset + itemsPerPage
    const currentItems = items?.slice(itemOffset, endOffset)
    const pageCount =
        items && items.length ? Math.ceil(items.length / itemsPerPage) : 0

    // Invoke when user click to request another page.
    const handlePageClick = event => {
        const newOffset = (event.selected * itemsPerPage) % items.length
        setItemOffset(newOffset)
    }

    const $targetEl = document.getElementById("delete-modal")
    const options = {
        onHide: () => {
            document.querySelector("[modal-backdrop]").remove()
        },
    }
    const modal = new Modal($targetEl, options)

    const [deleteItem, setDeleteItem] = useState(null)
    const toggleDelete = item => {
        setDeleteItem(item)
    }

    const handleDelete = item => {
        onDelete(item)
        modal.hide()
    }

    return (
        <>
            <DeleteModal
                item={deleteItem}
                onDelete={handleDelete}
                modal={modal}
            />
            {caption && (
                <TableHeader
                    caption={caption}
                    addNew={addNew}
                    onFilter={onFilter}
                />
            )}
            <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <TableHead headers={headers} withActions={withActions} />
                <tbody>
                    {currentItems.length ? (
                        currentItems.map((item, index) => (
                            <TableRow
                                item={item}
                                key={index}
                                headers={headers}
                                modal={modal}
                                routeRedirect={routeRedirect}
                                toggleView={onView}
                                toggleEdit={onEdit}
                                toggleDelete={toggleDelete}
                            />
                        ))
                    ) : (
                        <tr className="bg-gray-50 dark:bg-gray-800">
                            <td
                                colSpan={headers.length}
                                className="items-center py-4 px-6 space-x-3"
                            >
                                {caption && `No ${caption} found`}
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
            {currentItems.length && pageCount > 1 ? (
                <nav
                    className="flex items-center justify-between pt-4"
                    aria-label="Table navigation"
                >
                    <span className="text-sm font-normal text-gray-500 dark:text-gray-400">
                        Showing{" "}
                        <span className="font-semibold text-gray-900 dark:text-white">
                            {`${itemOffset} to ${endOffset}`}
                        </span>{" "}
                        of{" "}
                        <span className="font-semibold text-gray-900 dark:text-white">
                            {items.length}
                        </span>
                    </span>
                    <ReactPaginate
                        breakLabel="..."
                        nextLabel="next"
                        onPageChange={handlePageClick}
                        pageRangeDisplayed={5}
                        pageCount={pageCount}
                        previousLabel="previous"
                        renderOnZeroPageCount={null}
                        containerClassName="inline-flex items-center -space-x-px"
                        pageLinkClassName="px-3 py-2 leading-tight font-regular text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                        nextLinkClassName="block px-3 py-2 leading-tight font-regular text-gray-500 bg-white border border-gray-300 rounded-r-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                        previousLinkClassName="block px-3 py-2 ml-0 font-regular leading-tight text-gray-500 bg-white border border-gray-300 rounded-l-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
                        activeLinkClassName="z-10 px-3 py-2 font-regular leading-tight text-blue-600 border border-blue-300 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 dark:border-gray-700 dark:bg-gray-700 dark:text-white"
                    />
                </nav>
            ) : (
                ""
            )}
        </>
    )
}

Table.propTypes = {
    caption: PropTypes.string.isRequired,
    addNew: PropTypes.string,
    items: PropTypes.array.isRequired,
}

export default Table
