import PropTypes from "prop-types"
const FileInput = ({
    name,
    label,
    multiple,
    accept,
    fileAcceptText,
    register,
    errors,
    onSelectFile,
}) => {
    async function readFileAsync(file) {
        const reader = new FileReader()
        try {
            reader.onload = e => {
                onSelectFile(e.target.result, file)
            }
            reader.readAsDataURL(file)
        } catch (error) {
            return reader.onerror
        }
    }

    return (
        <>
            <label
                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                for={name}
            >
                {label}
            </label>
            <input
                {...register(name)}
                class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400"
                id={name}
                type="file"
                accept={accept}
                multiple={multiple}
                onChange={e => readFileAsync(e.target.files[0])}
            />
            <p
                class="mt-1 text-sm text-gray-500 dark:text-gray-300"
                id="file_input_help"
            >
                {fileAcceptText}
            </p>
            <p class="text-red-500 text-xs font-normal mt-1 first-letter:uppercase">
                {errors && errors[name]?.message.replaceAll("_", " ")}
            </p>
        </>
    )
}

FileInput.defaultProps = {
    label: "Input Sample",
    errors: [],
}

FileInput.propTypes = {
    name: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    multiple: PropTypes.bool,
    fileAccept: PropTypes.string.isRequired,
    register: PropTypes.func.isRequired,
}

export default FileInput
