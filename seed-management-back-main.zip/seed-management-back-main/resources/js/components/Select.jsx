import React from "react"
import PropTypes from "prop-types"

const Select = ({ name, label, options, register, errors }) => {
    return (
        <>
            <label
                for={name}
                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
            >
                {label}
            </label>
            <select
                name={name}
                {...register(name)}
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            >
                <option value="">Choose a {label}</option>
                {options.map(option => (
                    <option value={option.value}>{option.text}</option>
                ))}
            </select>
            <p class="text-red-500 text-xs font-normal mt-1 first-letter:uppercase">
                {errors && errors[name]?.message.replaceAll("_", " ")}
            </p>
        </>
    )
}

Select.defaultProps = {
    label: "Select Sample",
    options: [],
    errors: [],
}

Select.propTypes = {
    name: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    options: PropTypes.array.isRequired,
    register: PropTypes.func.isRequired,
}

export default Select
