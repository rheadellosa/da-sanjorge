import React from "react"
import AppBar from "./main/AppBar"
import Main from "./main/Main"
import Sidebar from "./main/Sidebar"

const MainLayout = () => {
    return (
        <div className="relative w-full min-h-screen">
            <AppBar />
            <Sidebar />
            <Main />
        </div>
    )
}

export default MainLayout
