import React, { useEffect, useState } from "react"
import { logout } from "../../api/auth"
import { useNavigate } from "react-router-dom"

const AppBar = () => {
    const navigate = useNavigate()
    const [isDark, setIsDark] = useState(false)

    const root = document.documentElement
    const toggleDarkMode = () => {
        setIsDark(!isDark)

        if (!isDark) {
            root.classList.add("dark")
            localStorage.setItem("theme", "dark")
        } else {
            root.classList.remove("dark")
            localStorage.setItem("theme", "light")
        }
    }
    const setRootElement = theme => {
        theme == "light"
            ? root.classList.remove("dark")
            : root.classList.add("dark")
    }
    useEffect(() => {
        const theme = localStorage.getItem("theme")
        theme == "light" ? setIsDark(false) : setIsDark(true)
        setRootElement(theme)
    }, [isDark])

    const user = JSON.parse(localStorage.getItem("user"))

    return (
        <header className="h-auto p-5 px-5 lg:px-10 lg:ml-64 flex justify-between">
            <button className="flex-none" type="button">
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="w-6 h-6 dark:text-white"
                >
                    <path
                        fillRule="evenodd"
                        d="M3 6.75A.75.75 0 013.75 6h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 6.75zM3 12a.75.75 0 01.75-.75h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 12zm0 5.25a.75.75 0 01.75-.75h16.5a.75.75 0 010 1.5H3.75a.75.75 0 01-.75-.75z"
                        clipRule="evenodd"
                    />
                </svg>
                <span className="sr-only">Icon description</span>
            </button>

            <div className="flex gap-5">
                <button type="button" onClick={() => toggleDarkMode()}>
                    {isDark ? (
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="currentColor"
                            className="w-6 h-6 dark:text-slate-100"
                        >
                            <path d="M12 2.25a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0V3a.75.75 0 01.75-.75zM7.5 12a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM18.894 6.166a.75.75 0 00-1.06-1.06l-1.591 1.59a.75.75 0 101.06 1.061l1.591-1.59zM21.75 12a.75.75 0 01-.75.75h-2.25a.75.75 0 010-1.5H21a.75.75 0 01.75.75zM17.834 18.894a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 10-1.061 1.06l1.59 1.591zM12 18a.75.75 0 01.75.75V21a.75.75 0 01-1.5 0v-2.25A.75.75 0 0112 18zM7.758 17.303a.75.75 0 00-1.061-1.06l-1.591 1.59a.75.75 0 001.06 1.061l1.591-1.59zM6 12a.75.75 0 01-.75.75H3a.75.75 0 010-1.5h2.25A.75.75 0 016 12zM6.697 7.757a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 00-1.061 1.06l1.59 1.591z" />
                        </svg>
                    ) : (
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="currentColor"
                            className="w-6 h-6"
                        >
                            <path
                                fillRule="evenodd"
                                d="M9.528 1.718a.75.75 0 01.162.819A8.97 8.97 0 009 6a9 9 0 009 9 8.97 8.97 0 003.463-.69.75.75 0 01.981.98 10.503 10.503 0 01-9.694 6.46c-5.799 0-10.5-4.701-10.5-10.5 0-4.368 2.667-8.112 6.46-9.694a.75.75 0 01.818.162z"
                                clipRule="evenodd"
                            />
                        </svg>
                    )}
                </button>

                <div
                    id="dropdownDefaultButton"
                    data-dropdown-toggle="user-dropdown"
                    className="flex items-center space-x-2 cursor-pointer"
                >
                    <img
                        className="w-10 h-10 rounded-full"
                        src={`${user.profile_img}`}
                        alt=""
                    />
                    <div className="font-medium dark:text-white text-left">
                        <div>{`${user?.first_name} ${user?.last_name}`}</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400 capitalize">
                            {user?.roles[0].name}
                        </div>
                    </div>
                </div>
                <div
                    id="user-dropdown"
                    class="z-10 hidden bg-white divide-y divide-gray-100 rounded shadow-md w-44 dark:bg-gray-800"
                >
                    <ul
                        class="py-1 text-sm text-gray-700 dark:text-gray-200"
                        aria-labelledby="dropdownDefaultButton"
                    >
                        <li
                            onClick={logout}
                            className="flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="1.5"
                                stroke="currentColor"
                                className="w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9"
                                />
                            </svg>

                            <a href="#" class="block px-2 py-2 ">
                                Sign out
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </header>
    )
}

export default AppBar
