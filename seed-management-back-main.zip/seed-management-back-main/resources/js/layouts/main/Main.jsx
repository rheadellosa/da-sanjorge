import React from "react"
import { Outlet } from "react-router-dom"
const Main = () => {
    const farmers = [
        {
            name: "John Doe",
            email: "test@user.com",
            img: "https://flowbite.com/docs/images/people/profile-picture-1.jpg",
            location: "Test Place",
            status: 1,
        },
        {
            name: "Jane Doe",
            email: "test@user.com",
            img: "https://flowbite.com/docs/images/people/profile-picture-2.jpg",
            location: "Test Place",
            status: 1,
        },
        {
            name: "Mark Ryan",
            email: "test@user.com",
            img: "https://flowbite.com/docs/images/people/profile-picture-3.jpg",
            location: "Test Place",
            status: 0,
        },
        {
            name: "Test user",
            email: "test@user.com",
            img: "https://flowbite.com/docs/images/people/profile-picture-4.jpg",
            location: "Test Place",
            status: 1,
        },
        {
            name: "Test Farmer",
            email: "test@user.com",
            img: "https://flowbite.com/docs/images/people/profile-picture-2.jpg",
            location: "Test Place",
            status: 0,
        },
    ]
    return (
        <main className="relative lg:ml-64 px-5 lg:px-10 mt-5 sm:rounded-lg pb-10 h-auto">
            <div className="px-1 relative sm:rounded-lg">
                <Outlet />
            </div>
        </main>
    )
}

export default Main
