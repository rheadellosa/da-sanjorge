import React from "react"
import { useMutation, useQuery, useQueryClient } from "react-query"
import { useNavigate, useParams } from "react-router"
import { fetchFarmer, updateFarmer } from "../../api/farmers"
import FarmerForm from "./FarmerForm"
const FarmerEdit = () => {
    const navigate = useNavigate()
    const { id } = useParams()
    const queryClient = useQueryClient()

    const { data } = useQuery(["farmer", id], () => fetchFarmer(id))

    const updateMutation = useMutation(updateFarmer, {
        onSuccess: () => {
            queryClient.invalidateQueries("farmers")
        },
    })

    const handleUpdateFarmer = async payload => {
        const formData = new FormData()
        const items = Object.keys(payload)
        items?.forEach(element => {
            if (payload[element]) {
                formData.append(element, payload[element])
            }
        })
        if (payload.img) {
            formData.append("img", payload.img[0])
        }
        if (payload.lands) {
            formData.append("lands", JSON.stringify(payload.lands))
        }
        if (payload.rsbsa_form) {
            formData.append("rsbsa_form", payload.rsbsa_form[0])
        }
        if (payload.tax_declaration) {
            formData.append("tax_declaration", payload.tax_declaration[0])
        }
        if (payload.brgy_clearance) {
            formData.append("brgy_clearance", payload.brgy_clearance[0])
        }
        if (payload.insurance) {
            formData.append("insurance", payload.insurance[0])
        }
        if (payload.valid_ids) {
            formData.append("valid_ids", payload.valid_ids[0])
        }
        if (payload.client_satisfaction) {
            formData.append(
                "client_satisfaction",
                payload.client_satisfaction[0]
            )
        }

        formData.append("_method", "PATCH")

        updateMutation.mutate(formData)
        navigate("/farmers")
    }

    return (
        <>
            <FarmerForm
                caption="Edit farmer"
                isEdit={true}
                values={data}
                onSubmit={handleUpdateFarmer}
            />
        </>
    )
}

export default FarmerEdit
