import React, { useEffect, useState } from "react"
import PropTypes from "prop-types"
import { Link, useNavigate } from "react-router-dom"
import { useQuery, useMutation, useQueryClient } from "react-query"
import { useForm } from "react-hook-form"
import { yupResolver } from "@hookform/resolvers/yup"
import * as yup from "yup"
import uuid from "react-uuid"
import { HiCheck } from "react-icons/hi"

import Input from "../../components/Input"
import Select from "../../components/Select"
import DatePicker from "../../components/DatePicker"
import FileInput from "../../components/FileInput"
import { fetchBarangays } from "../../api/barangays"

const FarmerSchema = yup
    .object()
    .shape({
        reference_id: yup.string().required(),
        first_name: yup.string().required(),
        middle_name: yup.string().required(),
        last_name: yup.string().required(),
        barangay: yup.string().required(),
        category: yup.string().required("Category is required.").nullable(),
    })
    .required()

const headers = [
    {
        text: "Location",
        value: "barangay",
        item_class: "",
    },
    {
        text: "Measurement (ha)",
        value: "measurement",
        item_class: "",
    },
    {
        text: "Type of Seed",
        value: "seed_type",
        item_class: "",
    },
    {
        text: "Action",
        value: "action",
        item_class: "",
    },
]

const seedTypes = [
    { value: "rice", text: "Rice" },
    { value: "corn", text: "Corn" },
    { value: "high-value-crops", text: "High Value Crops" },
]

const FarmerForm = ({ caption, isEdit, onSubmit, values }) => {
    const navigate = useNavigate()

    const { data: barangays, isLoading } = useQuery(["barangays"], () =>
        fetchBarangays()
    )

    const [lands, setLands] = useState([])
    const [land, setLand] = useState({
        id: "",
        uuid: "",
        measurement: "",
        seed_type: "",
        brgy_id: "",
        barangay: "",
    })

    // INIT FORM
    const {
        register,
        unregister,
        handleSubmit,
        setValue,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(FarmerSchema),
    })

    useEffect(() => {
        if (values) {
            if (values.lands) {
                setLands(
                    values.lands.map(item => ({
                        ...item,
                        uuid: uuid(),
                    }))
                )
            }
            setValues(values)
        }
    }, [values])

    // listen change of lands state and register the value to form
    useEffect(() => {
        setValues({ lands: lands })
        return () => {
            setValues({ lands: [] })
        }
    }, [lands])

    const setValues = fields => {
        Object.keys(fields).forEach(item => {
            setValue(item, fields[item])
        })

        if (fields.img) {
            setImgPreview(fields.img)
        }
    }

    //  HANDLE FILE Upload
    useEffect(() => {
        setValues({ img: img })
        return () => {
            setValues({ img: null })
        }
    }, [img])
    const [imgPreview, setImgPreview] = useState()
    const [img, setImg] = useState()
    const onSelectFile = (base64File, file) => {
        setImgPreview(base64File)
        setImg(file)
    }

    // CRUD FARMER'S LAND
    const handleLandForm = e => {
        const value = e.target.value
        setLand({
            ...land,
            [e.target.name]: value,
        })
    }

    // add land
    const clearLandFields = () => {
        setLand({
            id: "",
            uuid: "",
            measurement: "",
            seed_type: "",
            brgy_id: "",
            barangay: "",
        })
    }
    const saveLand = () => {
        if (!land.brgy_id || !land.measurement || !land.seed_type) {
            alert("Please check required fields!")
            return
        }
        const barangay = barangays.find(item => item.id == land.brgy_id)
        setLands([...lands, { ...land, uuid: uuid(), barangay }])
        clearLandFields()
    }
    const editLand = landEdit => {
        if (land.uuid) {
            alert("Please save the form first")
            return
        }
        setLand(lands.find(item => item.uuid == landEdit.uuid))
        setLands(lands.filter(item => item.uuid != landEdit.uuid))
    }
    const deleteLand = land => {
        setLands(lands.filter(item => item.uuid != land.uuid))
    }

    const submitForm = payload => {
        onSubmit(payload)
    }

    return (
        <>
            <div className="flex justify-between mb-5">
                <caption className="text-lg font-semibold text-left text-gray-900 bg-white dark:text-white dark:bg-inherit">
                    {caption}
                </caption>
                <Link to="/farmers">
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="1.5"
                        stroke="currentColor"
                        class="w-5 h-5 dark:text-white font-semibold cursor-pointer"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"
                        />
                    </svg>
                </Link>
            </div>
            <form
                onSubmit={handleSubmit(submitForm)}
                enctype="multipart/form-data"
                className="h-auto px-4 py-5 rounded-md w-100 bg-gray-50 dark:bg-gray-800 md:py-10 md:px-8"
            >
                {isEdit && (
                    <div className="mb-10">
                        <div>
                            <h2 className="mb-4 font-semibold text-gray-900 text-md dark:text-white">
                                QR Code
                            </h2>
                        </div>
                        <div class="flex items-center">
                            <div className="w-24 h-24 bg-slate-200">
                                <img
                                    src={values.qr_code}
                                    className="w-full h-full"
                                    alt=""
                                />
                            </div>
                            <div className="ml-4">
                                <p className="mb-2 ml-1 dark:text-white">
                                    REFERENCE CONTROL NO: {values.reference_id}
                                </p>
                                <button
                                    type="button"
                                    class="py-2.5 px-5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                                >
                                    Print QR
                                </button>
                            </div>
                        </div>
                    </div>
                )}
                <div>
                    <div>
                        <h2 className="mb-4 font-semibold text-gray-900 text-md dark:text-white">
                            Personal Information
                        </h2>
                    </div>
                    <div className="flex items-center gap-4 mb-4">
                        <div className="w-20 h-20 lg:w-28 lg:h-28">
                            <img
                                src={
                                    imgPreview
                                        ? imgPreview
                                        : "/assets/user.jpeg"
                                }
                                className="object-fill w-full h-full rounded-full"
                                alt=""
                            />
                        </div>
                        <div>
                            <FileInput
                                name="img"
                                label="Upload Profile Image"
                                multiple={false}
                                accept="image/*"
                                fileAcceptText="PNG, JPG."
                                register={register}
                                errors={errors}
                                onSelectFile={onSelectFile}
                            />
                        </div>
                    </div>
                    <div class="grid md:grid-cols-4 gap-y-4 md:gap-x-6 mb-8">
                        <div>
                            <Input
                                name="reference_id"
                                register={register}
                                errors={errors}
                                type="text"
                                label="Reference Control No"
                            />
                        </div>
                        <div>
                            <Input
                                name="first_name"
                                register={register}
                                errors={errors}
                                type="text"
                                label="First name"
                            />
                        </div>
                        <div>
                            <Input
                                name="middle_name"
                                register={register}
                                errors={errors}
                                type="text"
                                label="Middle name"
                            />
                        </div>
                        <div>
                            <Input
                                name="last_name"
                                register={register}
                                errors={errors}
                                type="text"
                                label="Last name"
                            />
                        </div>
                        <div>
                            <Input
                                name="extension_name"
                                register={register}
                                type="text"
                                label="Extension name"
                            />
                        </div>
                        <div>
                            <Input
                                name="contact_number"
                                register={register}
                                type="text"
                                label="Contact Number"
                            />
                        </div>
                    </div>
                    <h2 className="mb-4 font-semibold text-gray-900 text-md dark:text-white">
                        Category
                    </h2>
                    <div class="grid md:grid-cols-3 gap-y-4 md:gap-x-6 mb-8">
                        <div>
                            <Select
                                name="category"
                                register={register}
                                label="Category of farmer"
                                options={[
                                    {
                                        text: "Category A - 3 Crop/Commodity ",
                                        value: "category-a",
                                    },
                                    {
                                        text: "Category B - 2 Crop/Commodity ",
                                        value: "category-b",
                                    },
                                    {
                                        text: "Category C - 1 Crop/Commodity ",
                                        value: "category-c",
                                    },
                                ]}
                                errors={errors}
                            />
                        </div>
                    </div>
                    <h2 className="mb-4 font-semibold text-gray-900 text-md dark:text-white">
                        Address
                    </h2>
                    <div class="grid md:grid-cols-3 gap-y-4 md:gap-x-6 mb-8">
                        <div>
                            <Input
                                name="bldg_number"
                                register={register}
                                type="text"
                                label="House / Lot / Bldg. No."
                            />
                        </div>
                        <div>
                            <Input
                                name="street"
                                register={register}
                                type="text"
                                label="Street"
                            />
                        </div>
                        <div>
                            <Select
                                name="barangay"
                                register={register}
                                label="Barangay"
                                options={barangays}
                                errors={errors}
                            />
                        </div>
                        <div>
                            <Input
                                name="municipality"
                                register={register}
                                type="text"
                                label="Municipality"
                            />
                        </div>
                        <div>
                            <Input
                                name="province"
                                register={register}
                                type="text"
                                label="Province"
                            />
                        </div>
                        <div>
                            <Input
                                name="region"
                                register={register}
                                type="text"
                                label="Region"
                            />
                        </div>
                    </div>
                    <h2 className="mb-4 font-semibold text-gray-900 text-md dark:text-white">
                        Birth Information
                    </h2>
                    <div class="grid md:grid-cols-3 gap-y-4 md:gap-x-6 mb-8">
                        <div>
                            <DatePicker
                                id="birthDatePicker"
                                name="date_of_birth"
                                label="Date of Birth"
                                register={register}
                                errors={errors}
                            />
                        </div>
                        <div>
                            <Input
                                name="place_of_birth"
                                register={register}
                                type="text"
                                label="Place of birth"
                            />
                        </div>
                        <div>
                            <Input
                                name="religion"
                                register={register}
                                type="text"
                                label="Religion"
                            />
                        </div>
                        <div>
                            <Select
                                name="civil_status"
                                register={register}
                                label="Civil Status"
                                options={[
                                    { value: "single", text: "Single" },
                                    { value: "married", text: "Married" },
                                ]}
                                errors={errors}
                            />
                        </div>
                    </div>

                    <h2 className="mb-4 font-semibold text-gray-900 text-md dark:text-white">
                        Upload Documents
                    </h2>

                    {isEdit && (
                        <ul class="max-w-md space-y-1 text-gray-500 list-disc list-inside dark:text-gray-400 mb-4">
                            <li>
                                <div className="inline-flex items-center">
                                    <span>RSBSA FORM</span>
                                    {values?.document?.rsbsa_form && (
                                        <HiCheck className="inline ml-3 text-2xl text-primary-500" />
                                    )}
                                </div>
                            </li>
                            <li>
                                <div className="inline-flex items-center">
                                    <span>Tax declaration</span>
                                    {values?.document?.tax_declaration && (
                                        <HiCheck className="inline ml-3 text-2xl text-primary-500" />
                                    )}
                                </div>
                            </li>
                            <li>
                                <div className="inline-flex items-center">
                                    <span>Barangay Clearance</span>
                                    {values?.document?.brgy_clearance && (
                                        <HiCheck className="inline ml-3 text-2xl text-primary-500" />
                                    )}
                                </div>
                            </li>
                            <li>
                                <div className="inline-flex items-center">
                                    <span>Insurance</span>
                                    {values?.document?.insurance && (
                                        <HiCheck className="inline ml-3 text-2xl text-primary-500" />
                                    )}
                                </div>
                            </li>
                            <li>
                                <div className="inline-flex items-center">
                                    <span>Valid Id's</span>
                                    {values?.document?.valid_ids && (
                                        <HiCheck className="inline ml-3 text-2xl text-primary-500" />
                                    )}
                                </div>
                            </li>
                            <li>
                                <div className="inline-flex items-center">
                                    <span>Stab and Client Satisfaction</span>
                                    {values?.document?.client_satisfaction && (
                                        <HiCheck className="inline ml-3 text-2xl text-primary-500" />
                                    )}
                                </div>
                            </li>
                        </ul>
                    )}
                    <div className="grid mb-12 md:grid-cols-3 gap-y-6 md:gap-x-6">
                        <div>
                            <FileInput
                                name="rsbsa_form"
                                label="Upload RSBSA form"
                                multiple={false}
                                accept="application/msword, application/pdf, image/*"
                                fileAcceptText="MS WORD, PDF, IMAGE"
                                register={register}
                                errors={errors}
                                onSelectFile={() => console.log("uploaded")}
                            />
                        </div>

                        <div>
                            <FileInput
                                name="tax_declaration"
                                label="Upload Tax declaration"
                                multiple={false}
                                accept="application/msword, application/pdf, image/*"
                                fileAcceptText="MS WORD, PDF, IMAGE"
                                register={register}
                                errors={errors}
                                onSelectFile={() => console.log("uploaded")}
                            />
                        </div>
                        <div>
                            <FileInput
                                name="brgy_clearance"
                                label="Upload Barangay Clearance"
                                multiple={false}
                                accept="application/msword, application/pdf, image/*"
                                fileAcceptText="MS WORD, PDF, IMAGE"
                                register={register}
                                errors={errors}
                                onSelectFile={() => console.log("uploaded")}
                            />
                        </div>
                        <div>
                            <FileInput
                                name="insurance"
                                label="Upload Insurance"
                                multiple={false}
                                accept="application/msword, application/pdf, image/*"
                                fileAcceptText="MS WORD, PDF, IMAGE"
                                register={register}
                                errors={errors}
                                onSelectFile={() => console.log("uploaded")}
                            />
                        </div>
                        <div>
                            <FileInput
                                name="valid_ids"
                                label="Upload Valid Id's"
                                multiple={false}
                                accept="application/msword, application/pdf, image/*"
                                fileAcceptText="MS WORD, PDF, IMAGE"
                                register={register}
                                errors={errors}
                                onSelectFile={() => console.log("uploaded")}
                            />
                        </div>
                        <div>
                            <FileInput
                                name="client_satisfaction"
                                label="Upload Stab and Client Satisfaction"
                                multiple={false}
                                accept="application/msword, application/pdf, image/*"
                                fileAcceptText="MS WORD, PDF, IMAGE"
                                register={register}
                                errors={errors}
                                onSelectFile={() => console.log("uploaded")}
                            />
                        </div>
                    </div>
                    <div className="block grid-cols-5 mb-8 xl:grid gap-y-4 md:gap-x-6">
                        <div className="sm:mb-10 xl:col-span-3">
                            <h2 className="mb-4 font-semibold text-gray-900 text-md dark:text-white">
                                Lands
                            </h2>
                            <div className="relative overflow-x-auto">
                                <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                        <tr>
                                            <th scope="col" class="px-6 py-3">
                                                Location
                                            </th>
                                            <th scope="col" class="px-3 py-3">
                                                Measurement (ha)
                                            </th>
                                            <th scope="col" class="px-3 py-3">
                                                Seed Type
                                            </th>
                                            <th scope="col" class="px-3 py-3">
                                                Action
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {lands.length ? (
                                            lands.map((land, index) => (
                                                <tr
                                                    key={index}
                                                    class="bg-white border-b dark:bg-gray-800 dark:border-gray-700"
                                                >
                                                    <th
                                                        scope="row"
                                                        class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                                                    >
                                                        {land.barangay?.name}
                                                    </th>
                                                    <td class="px-3 py-4">
                                                        {land.measurement}
                                                    </td>
                                                    <td class="px-3 py-4">
                                                        {land.seed_type}
                                                    </td>
                                                    <td class="pl-6 py-4 px-3 flex gap-2">
                                                        <a
                                                            onClick={() =>
                                                                editLand(land)
                                                            }
                                                            className="font-medium text-blue-600 cursor-pointer w- dark:text-blue-500 hover:underline"
                                                        >
                                                            Edit
                                                        </a>
                                                        <a
                                                            onClick={() =>
                                                                deleteLand(land)
                                                            }
                                                            className="font-medium text-red-600 cursor-pointer dark:text-red-500 hover:underline"
                                                        >
                                                            Remove
                                                        </a>
                                                    </td>
                                                </tr>
                                            ))
                                        ) : (
                                            <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                                <td
                                                    class="px-6 py-4"
                                                    colSpan="4"
                                                >
                                                    No land registered
                                                </td>
                                            </tr>
                                        )}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div className="mt-4 xl:col-span-2 xl:mt-0">
                            <h2 className="mb-4 font-semibold text-gray-900 text-md dark:text-white">
                                {land.uuid ? "Edit" : "Add"} Land
                            </h2>
                            <div class="grid gap-y-4 md:gap-x-6">
                                <div>
                                    <label
                                        htmlFor="barangay"
                                        className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                                    >
                                        Location
                                        <small className="ml-1 text-red-500">
                                            *
                                        </small>
                                    </label>

                                    <select
                                        value={land.brgy_id}
                                        onChange={handleLandForm}
                                        name="brgy_id"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    >
                                        <option selected value="">
                                            Select location
                                        </option>
                                        {barangays?.map((item, index) => (
                                            <option key={index} value={item.id}>
                                                {item.name}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div>
                                    <label
                                        htmlFor="measurement"
                                        className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                                    >
                                        Measurement (UNIT HECTARE)
                                        <small className="ml-1 text-red-500">
                                            *
                                        </small>
                                    </label>
                                    <input
                                        name="measurement"
                                        value={land.measurement}
                                        onChange={handleLandForm}
                                        type="number"
                                        placeholder="measurement"
                                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    />
                                </div>
                                <div>
                                    <label
                                        htmlFor="measurement"
                                        className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                                    >
                                        CROP/COMMODITY
                                        <small className="ml-1 text-red-500">
                                            *
                                        </small>
                                    </label>
                                    <select
                                        value={land.seed_type}
                                        onChange={handleLandForm}
                                        name="seed_type"
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                    >
                                        <option selected>
                                            Select seed type
                                        </option>
                                        {seedTypes?.map((item, index) => (
                                            <option
                                                key={index}
                                                value={item.value}
                                            >
                                                {item.text}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            </div>
                            <div className="mt-5 text-right">
                                <a
                                    onClick={saveLand}
                                    className="text-right py-2.5 px-5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700 cursor-pointer"
                                >
                                    Save land
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="flex justify-end gap-2 mt-10">
                    <button
                        onClick={() => navigate("/farmers")}
                        class="px-5 py-2.5 text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                    >
                        Cancel
                    </button>
                    <button
                        type="submit"
                        class="px-5 py-2.5 text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm  dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800 text-right"
                    >
                        {`${isEdit ? "Update" : "Register new"}`} farmer
                    </button>
                </div>
            </form>
        </>
    )
}

FarmerForm.defaultProps = {
    caption: "Form",
    isEdit: false,
    values: {},
}

FarmerForm.propTypes = {
    caption: PropTypes.string,
    isEdit: PropTypes.bool,
    values: PropTypes.object,
}

export default FarmerForm
