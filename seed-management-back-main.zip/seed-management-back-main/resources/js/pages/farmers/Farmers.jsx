import Table from "../../components/Table"
import headers, { fetchFarmers, deleteFarmer } from "../../api/farmers"
import { useQuery, useMutation, useQueryClient } from "react-query"
import { useEffect, useState } from "react"

const Farmers = () => {
    const queryClient = useQueryClient()

    const [filter, setFilter] = useState({})
    const { data: farmers, isLoading } = useQuery(["farmers", filter], () =>
        fetchFarmers(filter)
    )

    const deleteMutation = useMutation(deleteFarmer, {
        onSuccess: () => {
            queryClient.invalidateQueries(["farmers", filter])
        },
    })
    const onDelete = item => {
        deleteMutation.mutate(item)
    }

    return (
        <>
            <Table
                caption="Farmers"
                addNew="/farmers/add"
                headers={headers}
                items={isLoading ? [] : farmers}
                itemsPerPage={10}
                onFilter={setFilter}
                onDelete={onDelete}
                routeRedirect="/farmers"
            />
        </>
    )
}

export default Farmers
