import React from "react"
import FarmerForm from "./FarmerForm"
import { useQuery, useMutation, useQueryClient } from "react-query"
import { storeFarmer } from "../../api/farmers"
import { useNavigate } from "react-router"

const FarmerAdd = () => {
    const navigate = useNavigate()
    const queryClient = useQueryClient()

    const storeMutation = useMutation(storeFarmer, {
        onSuccess: () => {
            queryClient.invalidateQueries("farmers")
        },
    })

    const handleStoreFarmer = async payload => {
        const formData = new FormData()
        const items = Object.keys(payload)
        items?.forEach(element => {
            if (payload[element]) {
                formData.append(element, payload[element])
            }
        })
        if (payload.img) {
            formData.append("img", payload.img[0])
        }
        if (payload.lands) {
            formData.append("lands", JSON.stringify(payload.lands))
        }
        if (payload.rsbsa_form) {
            formData.append("rsbsa_form", payload.rsbsa_form[0])
        }
        if (payload.tax_declaration) {
            formData.append("tax_declaration", payload.tax_declaration[0])
        }
        if (payload.brgy_clearance) {
            formData.append("brgy_clearance", payload.brgy_clearance[0])
        }
        if (payload.insurance) {
            formData.append("insurance", payload.insurance[0])
        }
        if (payload.valid_ids) {
            formData.append("valid_ids", payload.valid_ids[0])
        }
        if (payload.client_satisfaction) {
            formData.append(
                "client_satisfaction",
                payload.client_satisfaction[0]
            )
        }
        storeMutation.mutate(formData)
        navigate("/farmers")
    }

    return (
        <>
            <FarmerForm
                caption="Register new farmer"
                onSubmit={handleStoreFarmer}
            />
        </>
    )
}

export default FarmerAdd
