import React from "react"

import Table from "../../components/Table"

const headers = [
    {
        text: "ID",
        value: "id",
        item_class: "font-medium",
    },
    {
        text: "Name",
        value: "name",
        item_class: "font-medium",
    },

    {
        text: "Amount of Seeds (grams)",
        value: "total_amount",
        item_class: "",
    },
    {
        text: "Type",
        value: "type",
        item_class: "",
    },
    {
        text: "Number of beneficiaries/farmers",
        value: "total_farmers",
        item_class: "",
    },
    {
        text: "Distribution Date",
        value: "distribution_date",
        item_class: "",
    },
    {
        text: "Action",
        value: "action",
        item_class: "",
    },
]

const items = [
    {
        id: 1,
        name: "Distribution - June 2022",
        total_farmers: 32,
        total_amount: "100 grams",
        type: "native",
        distribution_date: "June 20, 2022",
        action: {
            edit: "redirect",
            delete: true,
        },
    },
    {
        id: 2,
        name: "Distribution - March 2022",
        total_farmers: 33,
        total_amount: "10 grams",
        type: "sweet corn",
        distribution_date: "March 10, 2023",
        action: {
            edit: "redirect",
            delete: true,
        },
    },
    {
        id: 3,
        name: "Distribution - July 2022",
        total_farmers: 50,
        total_amount: "300 grams",
        type: "native",
        distribution_date: "July 10, 2023",
        action: {
            edit: "redirect",
            delete: true,
        },
    },
]

const CornAccounting = () => (
    <Table
        caption="Corn Distribution"
        headers={headers}
        items={items}
        itemsPerPage={12}
        routeRedirect="/accounting/corn-distribution"
        addNew="/accounting/corn-distribution/add"
    />
)

export default CornAccounting
