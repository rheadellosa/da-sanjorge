import React, { useState } from "react"
import Input from "../../../../components/Input"

const seed_types = [
    { value: "sweet-corn", text: "Sweet Corn" },
    { value: "yellow-corn", text: "Yellow Corn" },
    { value: "opv-corn", text: "OPV corn" },
]

const units = [
    { value: "kg", text: "Kilogram" },
    { value: "g", text: "Gram" },
    { value: "mg", text: "Milligram" },
]

const seedSetup = ({ register, seeds, onSetSeeds }) => {
    const [seed, setSeed] = useState("")
    const [seedQty, setSeedQty] = useState(0)
    const [seedUnit, setSeedUnit] = useState("")

    const handleSubmit = () => {
        if (!seed || !seedQty)
            return alert("seed and seed quantity are required")

        const seedExists = seeds.find(item => item.seed === seed)
        if (seedExists) return alert("seed already exists")

        const newSeed = { seed, seedQty, seedUnit, available: seedQty }

        onSetSeeds(newSeed)
        setSeed("")
        setSeedQty(0)
        setSeedUnit("")
    }

    return (
        <div className="h-auto px-4 py-5 rounded-md w-100 bg-gray-50 dark:bg-gray-800 md:py-10 md:px-8">
            <div className="mb-6">
                <Input
                    label="Distribution name"
                    register={register}
                    type="text"
                    name="name"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                />
            </div>
            <h2 className="text-lg font-medium mb-4 dark:text-white">
                Seed Supply
            </h2>
            <div class="grid md:grid-cols-3 items-center gap-y-4 md:gap-x-6 mb-8">
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                        Seeds
                    </label>
                    <select
                        onChange={e => setSeed(e.target.value)}
                        value={seed}
                        name="seed"
                        type="text"
                        label="Seed"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                    >
                        <option value="">Choose a Seed</option>
                        {seed_types.map(option => (
                            <option value={option.value}>{option.text}</option>
                        ))}
                    </select>
                </div>
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                        Total Supply
                    </label>
                    <input
                        onChange={e => setSeedQty(e.target.value)}
                        value={seedQty}
                        type="number"
                        name="seed_qty"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                    />
                </div>
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                        Unit
                    </label>

                    <select
                        onChange={e => setSeedUnit(e.target.value)}
                        value={seedUnit}
                        name="seed"
                        type="text"
                        label="Seed"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                    >
                        <option value="">Choose a unit</option>
                        {units.map(option => (
                            <option value={option.value}>{option.text}</option>
                        ))}
                    </select>
                </div>
            </div>
            <div className="text-right">
                <button
                    type="button"
                    onClick={() => handleSubmit()}
                    class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-primary-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                >
                    Add seed
                </button>
            </div>
            {seeds.length ? (
                <div class="relative overflow-x-auto">
                    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" class="px-6 py-3">
                                    Name
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Total Supply
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Available Supply
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {seeds && seeds.length ? (
                                seeds.map(seed => (
                                    <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                        <th
                                            scope="row"
                                            class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                                        >
                                            {seed.seed}
                                        </th>
                                        <td class="px-6 py-4">
                                            {seed.seedQty} {seed.seedUnit}
                                        </td>
                                        <td class="px-6 py-4">
                                            {seed.available} {seed.seedUnit}
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <tr class="bg-white dark:bg-gray-800 dark:border-gray-700">
                                    <th
                                        colSpan={3}
                                        class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                                    >
                                        No data
                                    </th>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            ) : (
                ""
            )}
        </div>
    )
}

export default seedSetup
