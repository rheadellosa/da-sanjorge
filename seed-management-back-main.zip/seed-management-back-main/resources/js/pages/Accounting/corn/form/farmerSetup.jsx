import React, { useEffect, useState } from "react"
import { Combobox } from "@headlessui/react"
import { fetchFarmers } from "../../../../api/farmers"

const farmerSetup = ({ seeds, selectedFarmers, onSelectFarmer }) => {
    const [farmers, setFarmers] = useState([])

    const [selectedFarmer, setSelectedFarmer] = useState()
    const [query, setQuery] = useState("")

    const filteredFarmers =
        query === ""
            ? farmers
            : farmers.filter(farmer => {
                  return farmer.full_details
                      .toLowerCase()
                      .includes(query.toLowerCase())
              })

    useEffect(() => {
        const searchFarmers = async () => {
            const farmers = await fetchFarmers({ search: query })
            setFarmers(
                farmers.map(farmer => ({
                    ...farmer,
                    full_details: `${farmer.reference_id} - ${farmer.first_name} ${farmer.last_name}`,
                    name: `${farmer.first_name} ${farmer.last_name}`,
                }))
            )
        }
        searchFarmers()
    }, [query])

    const [selectedSeed, setSelectedSeed] = useState({})
    const [seed, setSeed] = useState({})
    const handleSeedChange = seed => {
        setSelectedSeed(seeds.find(item => item.seed === seed))
        setSeed(seed)
    }

    const [seedQty, setSeedQty] = useState(0)

    // handle submit selected farmer
    const handleSubmit = () => {
        if (![selectedFarmer, seed, seedQty].every(Boolean)) {
            return alert("All fields are required")
        }

        if (selectedFarmers.some(item => item.farmer === selectedFarmer)) {
            return alert("Farmer already exists")
        }

        if (Number(selectedSeed.available) < Number(seedQty)) {
            return alert("Seed quantity is not enough")
        }

        onSelectFarmer({
            farmer: selectedFarmer,
            seed,
            seedQty,
            seedUnit: selectedSeed.seedUnit,
        })
        setSelectedSeed({})
        setSelectedFarmer("")
        setSeed("")
        setSeedQty(0)
    }

    // watch selected farmer using useEffect and set state of grouped farmers base on seed
    const [groupedFarmers, setGroupedFarmers] = useState({})
    useEffect(() => {
        if (selectedFarmers.length > 0) {
            const groupedFarmers = selectedFarmers.reduce((acc, item) => {
                if (!acc[item.seed]) {
                    acc[item.seed] = []
                }
                acc[item.seed].push(item)
                return acc
            }, {})
            setGroupedFarmers(groupedFarmers)
        }
    }, [selectedFarmers])

    return (
        <div>
            <div className="mt-8 h-auto px-4 py-5 rounded-md w-100 bg-gray-50 dark:bg-gray-800 md:py-10 md:px-8">
                <h2 className="text-lg font-medium mb-4 dark:text-white">
                    Distribute seeds to farmers
                </h2>
                <div class="grid md:grid-cols-3 gap-y-4 md:gap-x-6 mb-8">
                    <div>
                        <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            Beneficiary
                        </label>
                        <Combobox
                            value={selectedFarmer}
                            onChange={setSelectedFarmer}
                        >
                            <Combobox.Input
                                onChange={event => setQuery(event.target.value)}
                                displayValue={farmer => farmer.full_details}
                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                            />
                            <Combobox.Options>
                                {filteredFarmers.map(farmer => (
                                    <Combobox.Option
                                        className="p-2.5 cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-600 dark:text-white"
                                        key={farmer.id}
                                        value={farmer}
                                        disabled={farmer.unavailable}
                                    >
                                        {farmer.full_details}
                                    </Combobox.Option>
                                ))}
                            </Combobox.Options>
                        </Combobox>
                    </div>
                    <div>
                        <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            Seeds
                        </label>
                        <select
                            onChange={e =>
                                handleSeedChange(e.currentTarget.value)
                            }
                            value={seed}
                            name="seed"
                            type="text"
                            label="Seed"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                        >
                            <option value="">Choose a Seed</option>
                            {seeds.map(
                                option =>
                                    option.available && (
                                        <option value={option.seed}>
                                            {option.seed}
                                        </option>
                                    )
                            )}
                        </select>
                    </div>
                    <div>
                        <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                            Amount{" "}
                            {selectedSeed &&
                                selectedSeed.available &&
                                `(available: ${selectedSeed?.available} ${selectedSeed?.seedUnit})`}
                        </label>
                        <input
                            onChange={e => setSeedQty(e.target.value)}
                            value={seedQty}
                            max={selectedSeed?.seedQty}
                            type="number"
                            name="seed_qty"
                            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                        />
                    </div>
                </div>
                <div className="text-right">
                    <button
                        type="button"
                        onClick={() => handleSubmit()}
                        class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-primary-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                    >
                        Add farmer
                    </button>
                </div>
            </div>
            <div className="mt-8 h-auto px-4 py-5 rounded-md w-100 bg-gray-50 dark:bg-gray-800 md:py-10 md:px-8">
                <h2 className="text-lg font-medium mb-4 dark:text-white">
                    Farmers grouped by seeds
                </h2>
                {groupedFarmers ? (
                    Object.keys(groupedFarmers).map((key, index) => (
                        <div className="mb-6">
                            <h2 className="text-md font-medium mb-4 dark:text-white">
                                {index + 1}.{" "}
                                <span className="capitalize">{key}</span>
                            </h2>
                            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                    <tr>
                                        <th scope="col" class="px-6 py-3">
                                            Reference ID
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            Name
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            Seed
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            Quantity
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {groupedFarmers[key].map(farmer => (
                                        <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                            <th
                                                scope="row"
                                                class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                                            >
                                                {farmer.farmer?.reference_id}
                                            </th>
                                            <th class="px-6 py-4">
                                                {farmer.farmer?.first_name}{" "}
                                                {farmer.farmer?.last_name}
                                            </th>
                                            <td class="px-6 py-4">
                                                {farmer.seed}
                                            </td>
                                            <td class="px-6 py-4">
                                                {farmer.seedQty}{" "}
                                                {farmer.seedUnit}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    ))
                ) : (
                    <div className="mt-8 h-auto px-4 py-5 rounded-md w-100 bg-gray-50 dark:bg-gray-800 md:py-10 md:px-8">
                        <h2 className="text-md font-medium mb-4 dark:text-white">
                            No farmers added yet
                        </h2>
                    </div>
                )}
            </div>
        </div>
    )
}

export default farmerSetup
