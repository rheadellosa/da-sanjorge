import React, { useEffect, useState } from "react"
import { useForm } from "react-hook-form"
import { yupResolver } from "@hookform/resolvers/yup"
import * as yup from "yup"
import { Link, useNavigate, useParams } from "react-router-dom"
import SeedSetup from "./seedSetup"
import FarmerSetup from "./farmerSetup"
import { useMutation } from "react-query"
import {
    fetchCornDistribution,
    storeCornDistribution,
    updateCornDistribution,
} from "../../../../api/corn_distribution"

const CornFormSchema = yup
    .object()
    .shape({
        name: yup.string().required(),
    })
    .required()

const CornForm = () => {
    const navigate = useNavigate()

    const [defaultSeeds, setDefaultSeeds] = useState([])
    const [seeds, setSeeds] = useState([])
    const [selectedFarmers, setSelectedFarmers] = useState([])

    // Distribution Details
    const { id } = useParams()

    // handle set initial values
    const setDistribution = async id => {
        const data = await fetchCornDistribution(id)

        const seedsData = JSON.parse(data.seeds)

        setValue("id", id)
        setValue("name", data.name)
        setDefaultSeeds(seedsData)
        setSeeds(
            seedsData.map(item => {
                const distributedSeeds = data.distributions.filter(
                    distribution => distribution.seed === item.seed
                )

                const distributedQty = distributedSeeds.reduce((acc, curr) => {
                    return acc + Number(curr.amount)
                }, 0)

                return {
                    ...item,
                    available: Number(item.available) - Number(distributedQty),
                }
            })
        )
        setSelectedFarmers(
            data.distributions.map(item => {
                return {
                    farmer: item.farmer,
                    seed: item.seed,
                    seedQty: item.amount,
                    seedUnit: item.unit,
                }
            })
        )
    }

    useEffect(() => {
        if (id) {
            setDistribution(id)
        }
    }, [id])

    // Init form
    const {
        register,
        handleSubmit,
        setValue,
        setError,
        getValues,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(CornFormSchema),
    })

    // decrease selected seed qty
    const handleDecreaseSeedQty = (seed, qty) => {
        const newSeeds = seeds.map(item => {
            if (item.seed === seed) {
                return {
                    ...item,
                    available: Number(item.available) - Number(qty),
                }
            }
            return item
        })
        setSeeds(newSeeds)
    }

    // handle farmer selection
    const handleSelectFarmer = farmer => {
        const newSelectedFarmers = [...selectedFarmers, farmer]
        setSelectedFarmers(newSelectedFarmers)
        handleDecreaseSeedQty(farmer.seed, farmer.seedQty)
    }

    // handle onSetSeed from seedSetup
    const onSetSeeds = () => seed => {
        setSeeds([...seeds, seed])
        setDefaultSeeds([...defaultSeeds, seed])
    }

    // handle submit form
    const submitForm = payload => {
        setValue("seeds", defaultSeeds)
        setValue("farmers", selectedFarmers)

        if (id) {
            updateMutation.mutate(payload)
        } else {
            storeMutation.mutate(payload)
        }

        navigate("/accounting/corn-distribution")
    }

    const storeMutation = useMutation(storeCornDistribution, {
        onSuccess: () => {
            queryClient.invalidateQueries("corn-distributions")
        },
    })
    const updateMutation = useMutation(updateCornDistribution, {
        onSuccess: () => {
            queryClient.invalidateQueries("corn-distributions")
        },
    })

    return (
        <>
            <div className="flex justify-between mb-5">
                <caption className="text-lg font-semibold text-left text-gray-900 bg-white dark:text-white dark:bg-inherit">
                    {id ? "Edit HVC Distribution" : "Add new HVC Distribution"}
                </caption>
                <Link to="/accounting/seed-distribution">
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="1.5"
                        stroke="currentColor"
                        class="w-5 h-5 dark:text-white font-semibold cursor-pointer"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"
                        />
                    </svg>
                </Link>
            </div>
            <form onSubmit={handleSubmit(submitForm)}>
                <SeedSetup
                    register={register}
                    seeds={seeds}
                    onSetSeeds={onSetSeeds()}
                />
                <FarmerSetup
                    seeds={seeds}
                    selectedFarmers={selectedFarmers}
                    onSelectFarmer={farmer => handleSelectFarmer(farmer)}
                />
                <div className="flex mt-6 justify-end">
                    <button
                        class="mt-6 px-5 py-2.5 text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm  dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800 text-right"
                        type="submit"
                    >
                        Submit Distribution
                    </button>
                </div>
            </form>
        </>
    )
}
export default CornForm
