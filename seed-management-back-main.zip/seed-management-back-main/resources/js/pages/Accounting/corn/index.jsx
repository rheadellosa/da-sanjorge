import React, { useState } from "react"

import Table from "../../../components/Table"
import { fetchCornDistributions } from "../../../api/corn_distribution"
import { useQuery } from "react-query"

const headers = [
    {
        text: "ID",
        value: "id",
        item_class: "font-medium",
    },
    {
        text: "Name",
        value: "name",
        item_class: "font-medium",
    },
    {
        text: "Number of beneficiaries/farmers",
        value: "total_farmers",
        item_class: "",
    },
    {
        text: "Action",
        value: "action",
        item_class: "",
    },
]

const CornAccounting = () => {
    const [filter, setFilter] = useState({})
    const { data: items, isLoading } = useQuery(
        ["corn-distributions", filter],
        () => fetchCornDistributions(filter)
    )

    console.log(items)
    return (
        <Table
            caption="Corn Distribution"
            headers={headers}
            items={items && items.length > 0 ? items : []}
            itemsPerPage={12}
            onFilter={setFilter}
            routeRedirect="/accounting/corn-distribution"
            addNew="/accounting/corn-distribution/add"
        />
    )
}
export default CornAccounting
