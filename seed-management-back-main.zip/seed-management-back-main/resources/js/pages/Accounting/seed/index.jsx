import React, { useState } from "react"

import Table from "../../../components/Table"
import { fetchSeedDistributions } from "../../../api/seed_distribution"
import { useQuery } from "react-query"

const headers = [
    {
        text: "ID",
        value: "id",
        item_class: "font-medium",
    },
    {
        text: "Name",
        value: "name",
        item_class: "font-medium",
    },
    {
        text: "Number of beneficiaries/farmers",
        value: "total_farmers",
        item_class: "",
    },
    {
        text: "Action",
        value: "action",
        item_class: "",
    },
]

const SeedAccounting = () => {
    const [filter, setFilter] = useState({})
    const { data: items, isLoading } = useQuery(
        ["seeds-distributions", filter],
        () => fetchSeedDistributions(filter)
    )

    console.log(items)
    return (
        <Table
            caption="HVC Distribution"
            headers={headers}
            items={items && items.length > 0 ? items : []}
            itemsPerPage={12}
            onFilter={setFilter}
            routeRedirect="/accounting/seed-distribution"
            addNew="/accounting/seed-distribution/add"
        />
    )
}
export default SeedAccounting
