import React, { useEffect, useState, Fragment } from "react"
import { useForm } from "react-hook-form"
import { yupResolver } from "@hookform/resolvers/yup"
import * as yup from "yup"
import { Link, useNavigate, useParams } from "react-router-dom"
import { Combobox } from "@headlessui/react"
import { useMutation, useQueryClient } from "react-query"

import Input from "../../../components/Input"
import Select from "../../../components/Select"
import DatePicker from "../../../components/DatePicker"
import { fetchFarmers } from "../../../api/farmers"
import {
    fetchRiceDistribution,
    storeRiceDistribution,
    updateRiceDistribution,
} from "../../../api/rice_distribution"

const RiceFormSchema = yup
    .object()
    .shape({
        name: yup.string().required(),
    })
    .required()

const RiceForm = () => {
    const queryClient = useQueryClient()
    const navigate = useNavigate()
    const { id } = useParams()
    const [distributions, setDistributions] = useState([])

    // Search farmer
    const [timer, setTimer] = useState(null)
    const [searchFarmer, setSearchFarmer] = useState("")
    const [searchFarmersResult, setSearchFarmersResult] = useState([])
    const [selectedFarmer, setSelectedFarmer] = useState(null)

    const setDistribution = async id => {
        const data = await fetchRiceDistribution(id)
        Object.keys(data).forEach(item => setValue(item, data[item]))
        const distributionsItems = data.distributions.map(item => ({
            ...item,
            barangay: item.farmer.barangay.name,
        }))
        setDistributions(distributionsItems)
    }

    useEffect(() => {
        if (id) {
            setDistribution(id)
        }
    }, [id])

    useEffect(() => {
        handleSearchFarmer()
    }, [searchFarmer])

    const handleSearchFarmer = async key => {
        if (!searchFarmer) {
            setSearchFarmersResult([])
            return
        }
        clearTimeout(timer)
        const newTimer = setTimeout(async () => {
            const farmerResults = await fetchFarmers({ search: searchFarmer })
            setSearchFarmersResult(farmerResults)
        }, 800)
        setTimer(newTimer)
    }

    // Select Farmer
    const [amount, setAmount] = useState(0)
    const handleSelectedFarmer = farmer => {
        if (!selectedFarmer.first_name) {
            return alert("please select farmer")
        }
        if (!amount) {
            return alert("please enter amount")
        }

        const data = {
            amount: amount,
            unit: null,
            farmer: farmer,
            barangay: farmer.barangay,
        }

        setDistributions([...distributions, data])
        setSearchFarmersResult(
            searchFarmersResult.filter(farmerItem => farmerItem.id != farmer.id)
        )
        setSearchFarmer("")
        setAmount(0)
        setSelectedFarmer({})
    }
    // Remove Farmer
    const removeFarmer = farmer => {
        setDistributions(
            distributions.filter(
                farmerItem =>
                    farmerItem.farmer.reference_id != farmer.farmer.reference_id
            )
        )
    }

    // Init form
    const {
        register,
        handleSubmit,
        setValue,
        setError,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(RiceFormSchema),
    })

    const storeMutation = useMutation(storeRiceDistribution, {
        onSuccess: () => {
            queryClient.invalidateQueries("rice-distributions")
        },
    })
    const updateMutation = useMutation(updateRiceDistribution, {
        onSuccess: () => {
            queryClient.invalidateQueries("rice-distributions")
        },
    })

    const submitForm = payload => {
        setValue("distributions", distributions)

        if (id) {
            updateMutation.mutate(payload)
        } else {
            storeMutation.mutate(payload)
        }
        navigate("/accounting/rice-distribution")
    }

    return (
        <>
            <div className="flex justify-between mb-5">
                <caption className="text-lg font-semibold text-left text-gray-900 bg-white dark:text-white dark:bg-inherit">
                    {id
                        ? "Edit Rice Distribution"
                        : "Add new Rice Distribution"}
                </caption>
                <Link to="/accounting/rice-distribution">
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke-width="1.5"
                        stroke="currentColor"
                        class="w-5 h-5 dark:text-white font-semibold cursor-pointer"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"
                        />
                    </svg>
                </Link>
            </div>
            <form
                onSubmit={handleSubmit(submitForm)}
                enctype="multipart/form-data"
                className="h-auto px-4 py-5 rounded-md w-100 bg-gray-50 dark:bg-gray-800 md:py-10 md:px-8"
            >
                <div>
                    <div class="grid md:grid-cols-3 gap-y-4 md:gap-x-6 mb-8">
                        <div>
                            <Input
                                name="name"
                                register={register}
                                errors={errors}
                                type="text"
                                label="Distribution name"
                            />
                        </div>
                        <div>
                            <Select
                                name="type"
                                label="Type of distribution"
                                options={[
                                    {
                                        text: "Financial Assistance",
                                        value: "Financial Assistance",
                                    },
                                    {
                                        text: "Fertilizer Assistance",
                                        value: "Fertilizer Assistance",
                                    },
                                    {
                                        text: "Equipment/ Tool Assistance",
                                        value: "Equipment/ Tool Assistance",
                                    },
                                ]}
                                register={register}
                                errors={errors}
                                type="text"
                            />
                        </div>
                        <div>
                            <DatePicker
                                id="distributionDatePicker"
                                name="distribution_date"
                                label="Date of Distribution"
                                register={register}
                                errors={errors}
                            />
                        </div>
                    </div>
                </div>

                {distributions && distributions.length ? (
                    <>
                        <h2 className="mb-4 font-semibold text-gray-900 text-md dark:text-white">
                            Farmers / Beneficiaries
                        </h2>
                        <div class="relative overflow-x-auto pb-6">
                            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                    <tr>
                                        <th scope="col" class="px-6 py-3">
                                            Reference ID
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            Full name
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            Barangay
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            Amount
                                        </th>
                                        <th scope="col" class="px-6 py-3">
                                            Action
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {distributions.map(
                                        (distribution, index) => (
                                            <tr
                                                key={index}
                                                class="bg-white border-b dark:bg-gray-800 dark:border-gray-700"
                                            >
                                                <th
                                                    scope="row"
                                                    class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                                                >
                                                    {
                                                        distribution.farmer
                                                            .reference_id
                                                    }
                                                </th>
                                                <td class="px-6 py-4">
                                                    {`${distribution.farmer.first_name} ${distribution.farmer.last_name}`}
                                                </td>
                                                <td class="px-6 py-4">
                                                    {distribution.barangay}
                                                </td>
                                                <th class="px-6 py-4">
                                                    {distribution.amount}
                                                </th>
                                                <td class="px-6 py-4 flex gap-3">
                                                    <a
                                                        onClick={() =>
                                                            removeFarmer(
                                                                distribution
                                                            )
                                                        }
                                                        href="#"
                                                        class="font-medium text-red-600 dark:text-red-500 hover:underline"
                                                    >
                                                        Remove
                                                    </a>
                                                </td>
                                            </tr>
                                        )
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </>
                ) : (
                    ""
                )}

                <div className="mt-10 p-4 bg-primary-100 rounded-lg">
                    <h2 className="mb-4 font-semibold text-gray-900 text-md dark:text-white">
                        Add Farmer Beneficiary
                    </h2>

                    <div className="grid grid-cols-3 gap-3 mt-4">
                        <div className="relative">
                            <label
                                for="first_name"
                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            >
                                Search farmer
                            </label>
                            <Combobox
                                value={selectedFarmer}
                                onChange={setSelectedFarmer}
                            >
                                <Combobox.Input
                                    className="block p-2 text-sm text-gray-900 border border-gray-300 rounded-lg w-full bg-gray-50 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    onChange={event =>
                                        setSearchFarmer(event.target.value)
                                    }
                                    displayValue={farmer =>
                                        farmer && searchFarmer
                                            ? `${farmer?.reference_id} - ${farmer?.first_name} ${farmer?.last_name}`
                                            : " "
                                    }
                                />
                                <Combobox.Options className="h-80 overflow-y-scroll absolute w-full bg-primary-50">
                                    {searchFarmersResult.map(farmer => (
                                        <Combobox.Option
                                            key={farmer.id}
                                            value={farmer}
                                            as={Fragment}
                                        >
                                            {({ active, selected }) => (
                                                <li
                                                    className={`px-3 py-2 cursor-pointer ${
                                                        active
                                                            ? "bg-primary-500 text-white"
                                                            : "bg-primary-100 text-black"
                                                    }`}
                                                >
                                                    {`${farmer?.reference_id} - ${farmer?.first_name} ${farmer?.last_name}`}
                                                </li>
                                            )}
                                        </Combobox.Option>
                                    ))}
                                </Combobox.Options>
                            </Combobox>
                        </div>
                        <div>
                            <label
                                for="amount"
                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            >
                                Amount
                            </label>
                            <input
                                value={amount}
                                onChange={e => setAmount(e.currentTarget.value)}
                                type="number"
                                id="table-search"
                                class="block p-2 text-sm text-gray-900 border border-gray-300 rounded-lg w-full bg-gray-50 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                placeholder="Amount"
                            />
                        </div>
                        <div>
                            <label
                                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                                for="feedback"
                            >
                                Client Satisfaction Feedback
                            </label>
                            <input
                                class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400"
                                id="feedback"
                                type="file"
                                accept="image/*"
                                multiple={false}
                                onChange={e => console.log(e.target.files[0])}
                            />
                        </div>
                    </div>
                    <button
                        onClick={() => handleSelectedFarmer(selectedFarmer)}
                        type="button"
                        class="mt-4 px-5 py-2.5 text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm  dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800 text-right"
                    >
                        Select Farmer
                    </button>
                </div>

                <div className="flex justify-end gap-2 mt-10">
                    <button
                        onClick={() =>
                            navigate("/accounting/rice-distribution")
                        }
                        class="px-5 py-2.5 text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                    >
                        Cancel
                    </button>
                    <button
                        type="submit"
                        class="px-5 py-2.5 text-white bg-primary-700 hover:bg-primary-800 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm  dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800 text-right"
                    >
                        {`${id ? "Update" : "Register new"}`} rice distribution
                    </button>
                </div>
            </form>
        </>
    )
}
export default RiceForm
