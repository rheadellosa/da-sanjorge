import React from "react"

import Table from "../../components/Table"

const headers = [
    {
        text: "ID",
        value: "id",
        item_class: "font-medium",
    },
    {
        text: "Name",
        value: "name",
        item_class: "font-medium",
    },
    {
        text: "Number of beneficiaries/farmers",
        value: "total_farmers",
        item_class: "",
    },
    {
        text: "Total amount of seeds",
        value: "seeds_amount",
        item_class: "",
    },
    {
        text: "Type",
        value: "type",
        item_class: "",
    },
    {
        text: "Distribution Date",
        value: "distribution_date",
        item_class: "",
    },
    {
        text: "Action",
        value: "action",
        item_class: "",
    },
]

const items = [
    {
        id: 1,
        name: "Distribution - June 2022",
        total_farmers: 32,
        seeds_amount: "50 kls",
        type: "Okra seeds",
        distribution_date: "June 20, 2022",
        action: {
            edit: "redirect",
            delete: true,
        },
    },
    {
        id: 2,
        name: "Distribution - March 2022",
        total_farmers: 33,
        seeds_amount: "60 kls",
        type: "Eggplant seeds",
        distribution_date: "March 10, 2023",
        action: {
            edit: "redirect",
            delete: true,
        },
    },
    {
        id: 3,
        name: "Corn Distribution - July 2022",
        total_farmers: 50,
        seeds_amount: "20 kls",
        type: "Corn seeds",
        distribution_date: "July 10, 2023",
        action: {
            edit: "redirect",
            delete: true,
        },
    },
]

const SeedAccounting = () => (
    <Table
        caption="HVC Distribution"
        headers={headers}
        items={items}
        itemsPerPage={12}
        routeRedirect="/accounting/seed-distribution"
        addNew="/accounting/seed-distribution/add"
    />
)
export default SeedAccounting
