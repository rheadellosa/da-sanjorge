import React, { useState } from "react"
import { useQuery, useQueryClient } from "react-query"
import { fetchRiceDistributions } from "../../api/rice_distribution"

import Table from "../../components/Table"

const headers = [
    {
        text: "ID",
        value: "id",
        item_class: "font-medium",
    },
    {
        text: "Name",
        value: "name",
        item_class: "font-medium",
    },
    {
        text: "Number of beneficiaries/farmers",
        value: "total_farmers",
        item_class: "",
    },
    {
        text: "Type",
        value: "type",
        item_class: "",
    },
    {
        text: "Distribution Date",
        value: "distribution_date",
        item_class: "",
    },
    {
        text: "Action",
        value: "action",
        item_class: "",
    },
]

const RiceAccounting = () => {
    const queryClient = useQueryClient()

    const [filter, setFilter] = useState({})
    const { data: items, isLoading } = useQuery(
        ["rice-distributions", filter],
        () => fetchRiceDistributions(filter)
    )
    return (
        <Table
            caption="Rice Distribution"
            headers={headers}
            items={isLoading ? [] : items}
            itemsPerPage={12}
            onFilter={setFilter}
            routeRedirect="/accounting/rice-distribution"
            addNew="/accounting/rice-distribution/add"
        />
    )
}

export default RiceAccounting
