import { useQuery, useMutation, useQueryClient } from "react-query"
import { useEffect, useState } from "react"
import { Modal } from "flowbite"

import Table from "../components/Table"
import { fetchLands } from "../api/lands"

const headers = [
    {
        text: "ID",
        value: "id",
        item_class: "font-medium",
    },
    {
        text: "Owner",
        value: "farmer",
        item_class: "font-medium",
    },
    {
        text: "Measurement (ha)",
        value: "measurement",
        item_class: "",
    },
    {
        text: "Barangay",
        value: "location",
        item_class: "",
    },
    {
        text: "Seed Type",
        value: "seed_type",
        item_class: "",
    },
    {
        text: "Action",
        value: "action",
        item_class: "",
    },
]

const ViewLand = ({ modal, data }) => {
    return (
        <>
            <div
                id="view-modal"
                data-modal-target="view-modal"
                tabIndex="-1"
                className="fixed top-0 left-0 right-0 z-50 hidden p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-modal md:h-full"
            >
                <div className="relative w-full h-full max-w-md md:h-auto">
                    <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                        <button
                            onClick={() => modal.hide()}
                            type="button"
                            class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-800 dark:hover:text-white"
                            data-modal-hide="view-modal"
                        >
                            <svg
                                aria-hidden="true"
                                class="w-5 h-5"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    fill-rule="evenodd"
                                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                    clip-rule="evenodd"
                                ></path>
                            </svg>
                            <span class="sr-only">Close modal</span>
                        </button>
                        <div class="px-6 py-8 lg:px-8">
                            <h3 class="mb-4 text-xl font-medium text-gray-900 dark:text-white">
                                Land Details
                            </h3>
                            <div className="grid gap-y-4">
                                <div>
                                    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Owner
                                    </label>
                                    <input
                                        value={data.farmer}
                                        disabled
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    />
                                </div>
                                <div>
                                    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Barangay
                                    </label>
                                    <input
                                        value={data.location}
                                        disabled
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    />
                                </div>
                                <div>
                                    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Measurement
                                    </label>
                                    <input
                                        value={data.measurement}
                                        disabled
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    />
                                </div>
                                <div>
                                    <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                        Seed Type
                                    </label>
                                    <input
                                        value={data.seed_type}
                                        disabled
                                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
                                    />
                                </div>
                            </div>
                            <div className="flex justify-end">
                                <button
                                    onClick={() => modal.hide()}
                                    data-modal-hide="bottom-right-modal"
                                    type="button"
                                    class="mt-6 text-right text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600"
                                >
                                    Close
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

const Lands = () => {
    const [filter, setFilter] = useState({})
    const { data: lands, isLoading } = useQuery(["lands", filter], () =>
        fetchLands(filter)
    )

    // view land
    const [land, setLand] = useState({})

    const $targetEl = document.getElementById("view-modal")
    const options = {
        onHide: () => {
            document.querySelector("[modal-backdrop]").remove()
        },
    }
    const modal = new Modal($targetEl, options)
    const toggleViewModal = item => {
        setLand(item)
        modal.show()
    }

    return (
        <>
            <ViewLand modal={modal} data={land} />
            <Table
                caption="Lands"
                onView={toggleViewModal}
                headers={headers}
                items={isLoading ? [] : lands}
                itemsPerPage={12}
                onFilter={setFilter}
            />
        </>
    )
}

export default Lands
