import React, { useEffect, useState } from "react"
import { useQuery, useQueryClient } from "react-query"
import { fetchAnnouncements } from "../api/announcements"
import moment from "moment"

const Announcement = () => {
    const { data: items, isLoading } = useQuery("announcements", () =>
        fetchAnnouncements()
    )
    return (
        <div className="w-10/12 pt-5 mx-auto ">
            <div className="flex justify-between">
                <div className="flex items-center">
                    <img
                        className="w-20 h-20 mr-2"
                        src="/assets/logo.png"
                        alt="logo"
                    />
                    <caption className="relative block font-semibold text-center bg-white text-primary-900 dark:text-white dark:bg-inherit">
                        WEB-BASED INFORMATION SYSTEM OF THE MUNICIPAL <br />
                        AGRICULTURE OFFICE OF SAN JORGE SAMAR
                    </caption>
                </div>

                <a
                    href="/login"
                    className="px-4 py-3 font-bold text-primary-500"
                >
                    LOGIN
                </a>
            </div>
            <caption className="relative block mt-10 mb-5 text-2xl font-semibold text-center text-gray-900 bg-white dark:text-white dark:bg-inherit">
                ANNOUNCEMENTS
            </caption>
            <section class="text-gray-600 body-font overflow-hidden ">
                {items &&
                    items.map(item => (
                        <div class="container px-6 py-16 mx-auto my-4 bg-primary-50 rounded-md">
                            <div class="-my-8 divide-y-2 divide-gray-100">
                                <div class="py-8 flex flex-wrap md:flex-nowrap">
                                    <div class="md:w-64 md:mb-0 mb-6 flex-shrink-0 flex flex-col">
                                        <span class="font-semibold title-font text-gray-700">
                                            ANNOUNCEMENT
                                        </span>
                                        <span class="mt-1 text-gray-500 text-sm">
                                            {moment(
                                                item.created_at,
                                                "YYYYMMDD"
                                            ).fromNow()}
                                        </span>
                                    </div>
                                    <div class="md:flex-grow">
                                        <h2 class="text-xl font-medium text-gray-900 title-font mb-2">
                                            {item.title}
                                        </h2>
                                        <p class="leading-relaxed">
                                            {item.content}
                                        </p>
                                        {/* <a class="text-indigo-500 inline-flex items-center mt-4">
                                            Learn More
                                            <svg
                                                class="w-4 h-4 ml-2"
                                                viewBox="0 0 24 24"
                                                stroke="currentColor"
                                                stroke-width="2"
                                                fill="none"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                            >
                                                <path d="M5 12h14"></path>
                                                <path d="M12 5l7 7-7 7"></path>
                                            </svg>
                                        </a> */}
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
            </section>
        </div>
    )
}

export default Announcement
