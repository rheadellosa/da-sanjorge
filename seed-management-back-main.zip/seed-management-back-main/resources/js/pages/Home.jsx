import React from "react"
import { useQuery, useQueryClient } from "react-query"
import { fetchDashboardStats } from "../api/dashboard"
const Home = () => {
    const queryClient = useQueryClient()
    const user = JSON.parse(localStorage.getItem("user"))

    const { data, isLoading } = useQuery(["dashboard-stats"], () =>
        fetchDashboardStats()
    )

    return (
        <>
            {/* <caption className="relative block mb-5 text-lg font-semibold text-left text-gray-900 bg-white dark:text-white dark:bg-inherit">
                WEB-BASED INFORMATION SYSTEM OF THE MUNICIPAL AGRICULTURE OFFICE
                OF SAN JORGE SAMAR
            </caption> */}
            <p className="relative block mb-5 text-sm text-left text-gray-800 bg-white dark:text-white dark:bg-inherit mt-6">
                Welcome back {user.first_name} {user.last_name}
            </p>
            <div>
                <caption className="relative block mb-5 text-lg font-semibold text-left text-gray-900 bg-white dark:text-white dark:bg-inherit">
                    Overview
                </caption>
                <div className="grid md:grid-cols-3 gap-y-4 md:gap-x-6 mb-8 text-white">
                    <div className="bg-primary-600 p-6 rounded-md">
                        <p className="text-sm text-gray-200">
                            Total Registered Farmers
                        </p>
                        <p className="text-4xl mt-3">{data?.total_farmers}</p>
                    </div>
                    <div className="bg-primary-600 p-6 rounded-md">
                        <p className="text-sm text-gray-200">
                            Total Registered Lands
                        </p>
                        <p className="text-4xl mt-3">{data?.total_lands}</p>
                    </div>
                    <div className="bg-primary-600 p-6 rounded-md">
                        <p className="text-sm text-gray-200">
                            Total Distribution
                        </p>
                        <p className="text-4xl mt-3">
                            {data?.total_distributions}
                        </p>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Home
