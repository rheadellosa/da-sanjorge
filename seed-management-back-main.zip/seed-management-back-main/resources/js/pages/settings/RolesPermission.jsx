import React, { useEffect, useState } from "react"
import { useQueryClient, useQuery, useMutation } from "react-query"
import {
    fetchRoles,
    fetchPermissions,
    syncRolePermissions,
} from "../../api/roles_permissions"

const RolesPermission = () => {
    const queryClient = useQueryClient()
    const { data: roles } = useQuery("roles", async () => {
        const data = await fetchRoles()

        return data
    })
    const { data: permissions } = useQuery("permissions", () =>
        fetchPermissions()
    )
    const roleSyncMutation = useMutation(syncRolePermissions, {
        onSuccess: () => {
            queryClient.invalidateQueries("roles")
        },
    })

    const [selectedRole, setSelectedRole] = useState(0)
    const [selectedPermissions, setSelectedPermissions] = useState([])

    const handleSelectRole = e => {
        if (e.target.value) {
            const role = roles.find(element => element.id == e.target.value)
            setSelectedRole(e.target.value)
            setSelectedPermissions(role.permissions.map(item => item.name))
        } else {
            setSelectedRole("")
            setSelectedPermissions([])
        }
    }

    const isChecked = key => {
        return selectedPermissions.includes(key)
    }
    const handleOnChangePermission = (e, key) => {
        console.log(key)
        if (e.target.checked) {
            setSelectedPermissions([...selectedPermissions, key])
        } else {
            setSelectedPermissions(
                selectedPermissions.filter(permission => permission !== key)
            )
        }
    }

    const handleSyncRolePermissions = () => {
        roleSyncMutation.mutate({
            permissions: selectedPermissions,
            id: selectedRole,
        })
    }

    return (
        <div className="min-h-full">
            <caption className="relative block mb-5 text-lg font-semibold text-left text-gray-900 bg-white dark:text-white dark:bg-inherit">
                Roles and Permissions
            </caption>

            <div className="w-64">
                <label
                    for="roles"
                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                >
                    Select role
                </label>
                <select
                    value={selectedRole}
                    onChange={e => handleSelectRole(e)}
                    id="roles"
                    class="bg-gray-50 border uppercase border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                >
                    <option value="" selected>
                        Choose role
                    </option>
                    {roles &&
                        roles.map((role, index) => (
                            <option value={role.id} key={index}>
                                {role.name}
                            </option>
                        ))}
                </select>
            </div>

            <div className="grid md:grid-cols-3 gap-y-4 md:gap-x-6 mt-8">
                {permissions &&
                    permissions.map((permission, index) => (
                        <div class="flex items-center mb-4" key={index}>
                            <input
                                id={permission.key}
                                type="checkbox"
                                value=""
                                defaultChecked={isChecked(permission.key)}
                                checked={isChecked(permission.key)}
                                onChange={e =>
                                    handleOnChangePermission(e, permission.key)
                                }
                                class="w-4 h-4 text-primary-600 bg-gray-100 border-gray-300 rounded focus:ring-primary-500 dark:focus:ring-primary-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                            />
                            <label
                                for={permission.key}
                                class="ml-2 capitalize text-sm font-medium text-gray-900 dark:text-gray-300"
                            >
                                {permission.name}
                            </label>
                        </div>
                    ))}
            </div>
            <div className="text-right mt-5">
                {selectedRole ? (
                    <button
                        onClick={handleSyncRolePermissions}
                        className="w-40 text-white bg-primary-600 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800 disabled:cursor-not-allowed"
                    >
                        Save Settings
                    </button>
                ) : (
                    <button
                        disabled
                        className="w-40 text-gray-300 bg-gray-600 hover:bg-gray-700 focus:ring-4 focus:outline-none focus:ring-gray-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-gray-600  dark:focus:ring-gray-800 disabled:cursor-not-allowed"
                    >
                        Save Settings
                    </button>
                )}
            </div>
        </div>
    )
}

export default RolesPermission
