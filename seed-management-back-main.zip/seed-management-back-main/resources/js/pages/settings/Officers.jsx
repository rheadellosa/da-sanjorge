import { useQuery, useMutation, useQueryClient } from "react-query"
import { useEffect, useState } from "react"
import { Modal } from "flowbite"
import { useForm } from "react-hook-form"
import { yupResolver } from "@hookform/resolvers/yup"
import * as yup from "yup"

import Table from "../../components/Table"
import {
    fetchOfficers,
    storeOfficer,
    updateOfficer,
    deleteOfficer,
} from "../../api/officers"
import { fetchRoles } from "../../api/roles_permissions"
import Input from "../../components/Input"
import Select from "../../components/Select"

const headers = [
    {
        text: "ID",
        value: "id",
        item_class: "font-medium",
    },
    {
        text: "Name",
        value: "first_name",
        item_class: "font-medium",
    },
    {
        text: "Email",
        value: "email",
        item_class: "",
    },
    {
        text: "Role",
        value: "role_name",
        item_class: "",
    },
    {
        text: "Action",
        value: "action",
        item_class: "",
    },
]
const Officers = () => {
    const queryClient = useQueryClient()
    const [filter, setFilter] = useState({})
    const { data: officers, isLoading } = useQuery(["officers", filter], () =>
        fetchOfficers(filter)
    )

    const [editItem, setEditItem] = useState()

    const $targetEl = document.getElementById("officer-form-modal")
    const options = {
        onHide: () => {
            document.querySelector("[modal-backdrop]").remove()
            setEditItem({})
        },
    }
    const modal = new Modal($targetEl, options)
    const toggleAddModalForm = () => {
        setEditItem(null)
        modal.show()
    }
    const toggleEditModalForm = item => {
        setEditItem(item)
        modal.show()
    }

    const deleteMutation = useMutation(deleteOfficer, {
        onSuccess: () => {
            queryClient.invalidateQueries("officers")
        },
    })
    const onDelete = item => {
        deleteMutation.mutate(item)
    }

    return (
        <>
            <OfficerForm modal={modal} data={editItem} />
            <Table
                caption="Officers"
                headers={headers}
                items={isLoading ? [] : officers}
                itemsPerPage={12}
                onFilter={setFilter}
                addNew={toggleAddModalForm}
                onEdit={toggleEditModalForm}
                onDelete={onDelete}
            />
        </>
    )
}

export default Officers

const OfficerSchema = yup
    .object()
    .shape({
        first_name: yup.string().required(),
        last_name: yup.string().required(),
        email: yup.string().required(),
    })
    .required()

const OfficerForm = ({ modal, data }) => {
    const queryClient = useQueryClient()
    const { data: roles } = useQuery("roles", async () => fetchRoles())

    // Init form
    const {
        register,
        handleSubmit,
        setValue,
        setError,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(OfficerSchema),
    })

    useEffect(() => {
        if (data) {
            console.log(data)
            Object.keys(data).forEach(item => {
                setValue(item, data[item])
            })
        } else {
            console.log("no data")
            const fields = [
                "first_name",
                "last_name",
                "email",
                "password",
                "role",
            ]
            fields.forEach(field => setValue(field, ""))
        }
    }, [data])

    const setErrors = errors => {
        Object.keys(errors).forEach(error => {
            setError(error, { type: "custom", message: errors[error][0] })
        })
    }

    const storeMutation = useMutation(storeOfficer, {
        onSuccess: () => {
            queryClient.invalidateQueries("officers")
            modal.hide()
        },
        onError: error => {
            setErrors(error.response.data.errors)
        },
    })
    const updateMutation = useMutation(updateOfficer, {
        onSuccess: () => {
            queryClient.invalidateQueries("officers")
            modal.hide()
        },
        onError: error => {
            setErrors(error.response.data.errors)
        },
    })

    const submitForm = async payload => {
        if (payload.id) {
            updateMutation.mutate(payload)
        } else {
            storeMutation.mutate(payload)
        }
    }

    return (
        <>
            <div
                id="officer-form-modal"
                data-modal-target="officer-form-modal"
                tabIndex="-1"
                className="fixed top-0 left-0 right-0 z-50 hidden p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-modal md:h-full"
            >
                <div className="relative w-full h-full max-w-md md:h-auto">
                    <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                        <button
                            onClick={() => modal.hide()}
                            type="button"
                            class="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-800 dark:hover:text-white"
                            data-modal-hide="officer-form-modal"
                        >
                            <svg
                                aria-hidden="true"
                                class="w-5 h-5"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    fill-rule="evenodd"
                                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                    clip-rule="evenodd"
                                ></path>
                            </svg>
                            <span class="sr-only">Close modal</span>
                        </button>
                        <form
                            onSubmit={handleSubmit(submitForm)}
                            class="px-6 py-8 lg:px-8"
                        >
                            <h3 class="mb-4 text-xl font-medium text-gray-900 dark:text-white">
                                {data?.id ? "Edit Officer" : "Add New Officer"}
                            </h3>
                            <div className="grid gap-y-4 md:gap-x-6 mb-8">
                                <div>
                                    <Input
                                        name="first_name"
                                        register={register}
                                        errors={errors}
                                        type="text"
                                        label="First name"
                                    />
                                </div>
                                <div>
                                    <Input
                                        name="last_name"
                                        register={register}
                                        errors={errors}
                                        type="text"
                                        label="Last name"
                                    />
                                </div>
                                <div>
                                    <Input
                                        name="email"
                                        register={register}
                                        errors={errors}
                                        type="email"
                                        label="Email"
                                    />
                                </div>
                                {!data?.id && (
                                    <div>
                                        <Input
                                            name="password"
                                            register={register}
                                            errors={errors}
                                            type="text"
                                            label="Password"
                                        />
                                    </div>
                                )}
                                <div>
                                    <Select
                                        name="role"
                                        register={register}
                                        label="Role"
                                        options={roles}
                                        errors={errors}
                                    />
                                </div>
                            </div>
                            <div className="flex justify-end gap-2">
                                <button
                                    onClick={() => modal.hide()}
                                    data-modal-hide="bottom-right-modal"
                                    type="button"
                                    class="mt-6 text-right text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600"
                                >
                                    Close
                                </button>
                                <button
                                    data-modal-hide="bottom-right-modal"
                                    type="submit"
                                    class="mt-6 text-right bg-primary-600 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800 text-white"
                                >
                                    {data?.id ? "Update" : "Save"}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}
