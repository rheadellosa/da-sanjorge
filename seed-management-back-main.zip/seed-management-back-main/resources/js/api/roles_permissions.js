import Axios from "../libs/axios"

// ROLES
export const fetchRoles = async () => {
    try {
        const { data } = await Axios.get("/roles")
        return data.map(item => {
            return {
                ...item,
                text: item.name,
                value: item.id,
            }
        })
    } catch (error) {
        return error
    }
}

export const syncRolePermissions = async payload => {
    const id = payload.id
    try {
        const { data } = await Axios.post(
            `/sync-role-permissions/${id}`,
            payload
        )
        return data
    } catch (error) {
        return error
    }
}

// PERMISSIONS
export const fetchPermissions = async () => {
    try {
        const { data } = await Axios.get("/permissions")
        return data.map(item => {
            return {
                ...item,
                name: item.name.replace(/_/g, " "),
                key: item.name,
            }
        })
    } catch (error) {
        return error
    }
}
