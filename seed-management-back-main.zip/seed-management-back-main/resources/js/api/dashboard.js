import Axios from "../libs/axios"

export const fetchDashboardStats = async () => {
    try {
        const { data } = await Axios.get("/dashboard-stats")
        return data
    } catch (error) {
        return error
    }
}
