import Axios from "../libs/axios"

export const fetchBarangays = async filter => {
    try {
        const { data } = await Axios.get("/barangays", {
            params: { ...filter },
        })
        return data.map(item => {
            return {
                ...item,
                text: item.name,
                value: item.id,
                total_farmers: item.farmers?.length,
                total_lands: item.lands?.length,
                action: {
                    edit: "modal",
                    delete: true,
                },
            }
        })
    } catch (error) {
        return error
    }
}

export const storeBarangay = async payload => {
    try {
        const { data } = await Axios.post("/barangays", payload)
        return data
    } catch (error) {
        console.log(error)
    }
}

export const updateBarangay = async payload => {
    const id = payload.id
    try {
        const { data } = await Axios.put(`/barangays/${id}`, payload)
        return data
    } catch (error) {
        console.log(error)
    }
}

export const deleteBarangay = async item => {
    try {
        const { data } = await Axios.delete(`/barangays/${item.id}`)
        return data
    } catch (error) {
        return error
    }
}
