import Axios from "../libs/axios"

export const fetchSeedDistributions = async filter => {
    try {
        const { data } = await Axios.get("/seed-distributions", {
            params: { ...filter },
        })
        return data.map(distribution => {
            return {
                ...distribution,
                total_farmers: distribution.distributions.length,
                action: {
                    edit: "redirect",
                    delete: true,
                },
            }
        })
    } catch (error) {
        return error
    }
}

export const storeSeedDistribution = async payload => {
    try {
        const { data } = await Axios.post("/seed-distributions", payload)
        return data
    } catch (error) {
        console.log(error)
    }
}

export const fetchSeedDistribution = async id => {
    try {
        const { data } = await Axios.get(`/seed-distributions/${id}`)
        return data
    } catch (error) {
        return error
    }
}

export const updateSeedDistribution = async payload => {
    const id = payload.id
    try {
        const { data } = await Axios.put(`/seed-distributions/${id}`, payload)
        return data
    } catch (error) {
        console.log(error)
    }
}
