import Axios from "../libs/axios"

export const fetchOfficers = async filter => {
    try {
        const { data } = await Axios.get("/officers", {
            params: { ...filter },
        })
        return data.map(item => {
            return {
                ...item,
                role_name: item.roles[0] ? item.roles[0].name : "",
                role: item.roles[0] ? item.roles[0].id : "",
                action: {
                    edit: "modal",
                    delete: true,
                },
            }
        })
    } catch (error) {
        return error
    }
}

export const storeOfficer = async payload => {
    try {
        const { data } = await Axios.post("/officers", payload)
        return data
    } catch (error) {
        throw error
    }
}

export const updateOfficer = async payload => {
    const id = payload.id
    try {
        const { data } = await Axios.put(`/officers/${id}`, payload)
        return data
    } catch (error) {
        throw error
    }
}

export const deleteOfficer = async item => {
    try {
        const { data } = await Axios.delete(`/officers/${item.id}`)
        return data
    } catch (error) {
        return error
    }
}
