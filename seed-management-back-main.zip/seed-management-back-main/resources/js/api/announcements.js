import Axios from "../libs/axios"
import moment from "moment"
export const fetchAnnouncements = async filter => {
    try {
        const { data } = await Axios.get("/announcements")
        return data.map(item => {
            return {
                ...item,
                posted_at: moment(item.created_at, "YYYYMMDD").fromNow(),
                action: {
                    delete: true,
                },
            }
        })
    } catch (error) {
        return error
    }
}

export const fetchAnnouncementsAdmin = async filter => {
    try {
        const { data } = await Axios.get("/announcements-admin")
        return data.map(item => {
            return {
                ...item,
                posted_at: moment(item.created_at, "YYYYMMDD").fromNow(),
                action: {
                    edit: "modal",
                    delete: true,
                },
            }
        })
    } catch (error) {
        return error
    }
}

export const storeAnnouncement = async payload => {
    try {
        const { data } = await Axios.post("/announcements-admin", payload)
        return data
    } catch (error) {
        throw error
    }
}

export const updateAnnouncement = async payload => {
    const id = payload.id
    try {
        const { data } = await Axios.put(`/announcements-admin/${id}`, payload)
        return data
    } catch (error) {
        throw error
    }
}

export const deleteAnnouncement = async item => {
    try {
        const { data } = await Axios.delete(`/announcements-admin/${item.id}`)
        return data
    } catch (error) {
        return error
    }
}
