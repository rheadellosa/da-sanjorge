import Axios from "../libs/axios"

export const fetchCornDistributions = async filter => {
    try {
        const { data } = await Axios.get("/corn-distributions", {
            params: { ...filter },
        })
        return data.map(distribution => {
            return {
                ...distribution,
                total_farmers: distribution.distributions.length,
                action: {
                    edit: "redirect",
                    delete: true,
                },
            }
        })
    } catch (error) {
        return error
    }
}

export const storeCornDistribution = async payload => {
    try {
        const { data } = await Axios.post("/corn-distributions", payload)
        return data
    } catch (error) {
        console.log(error)
    }
}

export const fetchCornDistribution = async id => {
    try {
        const { data } = await Axios.get(`/corn-distributions/${id}`)
        return data
    } catch (error) {
        return error
    }
}

export const updateCornDistribution = async payload => {
    const id = payload.id
    try {
        const { data } = await Axios.put(`/corn-distributions/${id}`, payload)
        return data
    } catch (error) {
        console.log(error)
    }
}
