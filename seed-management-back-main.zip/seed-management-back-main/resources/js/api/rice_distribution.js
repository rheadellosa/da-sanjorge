import Axios from "../libs/axios"

export const fetchRiceDistributions = async filter => {
    try {
        const { data } = await Axios.get("/rice-distributions", {
            params: { ...filter },
        })
        return data.map(distribution => {
            return {
                ...distribution,
                total_farmers: distribution.distributions.length,
                action: {
                    edit: "redirect",
                    delete: true,
                },
            }
        })
    } catch (error) {
        return error
    }
}

export const storeRiceDistribution = async payload => {
    try {
        const { data } = await Axios.post("/rice-distributions", payload)
        return data
    } catch (error) {
        console.log(error)
    }
}

export const fetchRiceDistribution = async id => {
    try {
        const { data } = await Axios.get(`/rice-distributions/${id}`)
        return data
    } catch (error) {
        return error
    }
}

export const updateRiceDistribution = async payload => {
    const id = payload.id
    try {
        const { data } = await Axios.put(`/rice-distributions/${id}`, payload)
        return data
    } catch (error) {
        console.log(error)
    }
}
