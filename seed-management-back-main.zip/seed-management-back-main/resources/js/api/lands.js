import Axios from "../libs/axios"

export const fetchLands = async filter => {
    try {
        const { data } = await Axios.get("/lands", { params: { ...filter } })
        return data.map(item => {
            return {
                ...item,
                measurement: `${item.measurement} ha`,
                farmer: `${item.farmer.first_name} ${item.farmer.last_name}`,
                location: `${item.barangay.name}`,
                action: {
                    view: "modal",
                },
            }
        })
    } catch (error) {
        return error
    }
}
