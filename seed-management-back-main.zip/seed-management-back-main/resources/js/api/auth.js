import Axios from "../libs/axios"

export const getUser = async () => {
    try {
        const { data } = await Axios.get("/user")

        return data
    } catch (error) {
        throw error
    }
}

export const login = async credentials => {
    try {
        const {
            data: { token, user },
        } = await Axios.post("/login", { ...credentials })

        localStorage.setItem("user", JSON.stringify(user))
        return token
    } catch (error) {
        throw error
    }
}

export const logout = async () => {
    try {
        const { data } = await Axios.post("/logout")
        localStorage.removeItem("token")
        localStorage.removeItem("user")
        window.location.reload()
        return data
    } catch (error) {
        throw error
    }
}
