import Axios from "../libs/axios"

const headers = [
    {
        text: "ID",
        value: "reference_id",
        item_class: "font-medium",
    },
    {
        text: "Name",
        value: "full_name",
        item_class: "",
    },
    {
        text: "Contact Number",
        value: "contact_number",
        item_class: "",
    },
    {
        text: "Barangay",
        value: "barangay",
        item_class: "",
    },
    {
        text: "Category",
        value: "category",
        item_class: "",
    },
    {
        text: "Action",
        value: "action",
        item_class: "",
    },
]
export default headers

export const fetchFarmers = async filter => {
    try {
        const { data } = await Axios.get("/farmers", { params: { ...filter } })
        return data.map(item => {
            return {
                ...item,
                barangay: item.barangay.name,
                full_name: `${item.last_name}, ${item.first_name}  ${item.middle_name}`,
                action: {
                    edit: "redirect",
                    delete: true,
                },
            }
        })
    } catch (error) {
        return error
    }
}

export const fetchFarmer = async id => {
    try {
        const { data } = await Axios.get(`/farmers/${id}`)
        return { ...data, barangay: data.brgy_id }
    } catch (error) {
        return error
    }
}

export const storeFarmer = async payload => {
    try {
        const { data } = await Axios.post("/farmers", payload)
        return data
    } catch (error) {
        console.log(error)
    }
}

export const updateFarmer = async payload => {
    console.log(payload, "update")
    const id = payload.get("id")
    try {
        const { data } = await Axios.post(`/farmers/${id}`, payload)
        return data
    } catch (error) {
        console.log(error)
    }
}

export const deleteFarmer = async item => {
    try {
        const { data } = await Axios.delete(`/farmers/${item.id}`)
        return data
    } catch (error) {
        return error
    }
}
