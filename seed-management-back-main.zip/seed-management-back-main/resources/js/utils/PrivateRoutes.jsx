import { Outlet, Navigate } from "react-router-dom"
import useToken from "../hooks/useToken"

const PrivateRoutes = () => {
    const { token, setToken } = useToken()

    return token ? <Outlet /> : <Navigate to="/announcements" />
}

export default PrivateRoutes
