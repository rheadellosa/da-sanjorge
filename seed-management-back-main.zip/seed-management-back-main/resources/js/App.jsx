import { createContext, useEffect, useState } from "react"
import { QueryClient, QueryClientProvider } from "react-query"
import { Route, Routes, useNavigate } from "react-router-dom"
import MainLayout from "./layouts/MainLayout"
import Home from "./pages/Home"
import Login from "./pages/Login"
import Farmers from "./pages/farmers/Farmers"
import FarmerEdit from "./pages/farmers/FarmerEdit"
import FarmerAdd from "./pages/farmers/FarmerAdd"
import PrivateRoutes from "./utils/PrivateRoutes"
import useToken from "./hooks/useToken"
import Lands from "./pages/Lands"
import Barangays from "./pages/Barangays"
import RolesPermission from "./pages/settings/RolesPermission"
import Officers from "./pages/settings/Officers"
import RiceAccounting from "./pages/accounting/RiceAccounting"
import CornAccounting from "./pages/accounting/corn"
import RiceForm from "./pages/accounting/forms/RiceForm"
import SeedAccounting from "./pages/accounting/seed"
import SeedForm from "./pages/accounting/seed/form"
import CornForm from "./pages/accounting/corn/form"
import { getUser } from "./api/auth"
import { AppContext } from "./context"
import Announcement from "./pages/Announcement"
import PostAnnouncements from "./pages/PostAnnouncements"

const queryClient = new QueryClient()

function App() {
    const navigate = useNavigate()
    const { token, setToken } = useToken()
    const [permissions, setPermissions] = useState([])

    // set light theme
    if (!localStorage.getItem("theme")) {
        localStorage.setItem("theme", "light")
    }

    useEffect(() => {
        const fetchUserPermissions = async () => {
            const user = await getUser()
            setPermissions(user.roles[0].permissions.map(item => item.name))
        }

        fetchUserPermissions()

        return () => {}
    }, [])

    // check has permission
    const hasPermission = permission => {
        return permissions.includes(permission)
    }

    return (
        <>
            <QueryClientProvider client={queryClient}>
                <AppContext.Provider value={{ hasPermission }}>
                    <Routes>
                        <Route element={<PrivateRoutes />}>
                            <Route path="/" element={<MainLayout />}>
                                <Route index element={<Home />} />

                                <Route path="farmers">
                                    <Route index element={<Farmers />} />
                                    <Route
                                        path="edit/:id"
                                        element={<FarmerEdit />}
                                    />
                                    <Route path="add" element={<FarmerAdd />} />
                                </Route>
                                <Route path="accounting">
                                    <Route path="rice-distribution">
                                        <Route
                                            index
                                            element={<RiceAccounting />}
                                        ></Route>
                                        <Route
                                            path="add"
                                            element={<RiceForm />}
                                        ></Route>
                                        <Route
                                            path="edit/:id"
                                            element={<RiceForm />}
                                        ></Route>
                                    </Route>
                                    <Route path="seed-distribution">
                                        <Route
                                            index
                                            element={<SeedAccounting />}
                                        ></Route>
                                        <Route
                                            path="add"
                                            element={<SeedForm />}
                                        ></Route>
                                        <Route
                                            path="edit/:id"
                                            element={<SeedForm />}
                                        ></Route>
                                    </Route>
                                    <Route path="corn-distribution">
                                        <Route
                                            index
                                            element={<CornAccounting />}
                                        ></Route>
                                        <Route
                                            path="add"
                                            element={<CornForm />}
                                        ></Route>
                                        <Route
                                            path="edit/:id"
                                            element={<CornForm />}
                                        ></Route>
                                    </Route>
                                </Route>
                                <Route path="/lands" element={<Lands />} />
                                <Route
                                    path="/barangays"
                                    element={<Barangays />}
                                />
                                <Route
                                    path="/post-announcements"
                                    element={<PostAnnouncements />}
                                />
                                <Route path="settings">
                                    <Route
                                        path="roles-permissions"
                                        element={<RolesPermission />}
                                    />
                                    <Route
                                        path="officers"
                                        element={<Officers />}
                                    />
                                </Route>
                            </Route>
                        </Route>
                        <Route
                            path="/announcements"
                            element={<Announcement />}
                        />
                        <Route
                            path="/login"
                            element={
                                <Login setToken={setToken} token={token} />
                            }
                        />
                    </Routes>
                </AppContext.Provider>
            </QueryClientProvider>
        </>
    )
}

export default App
