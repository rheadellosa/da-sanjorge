<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>WEB-BASED INFORMATION SYSTEM OF THE MUNICIPAL AGRICULTURE OFFICE OF SAN JORGE SAMAR</title>
    <link rel="stylesheet" href="https://rsms.me/inter/inter.css">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>

<body class="antialiased">

    <div id="root" class="dark:bg-gray-700 min-h-screen"></div>
    <script src="{{ mix('/js/main.js') }}"></script>
    <script src="https://unpkg.com/flowbite@1.6.0/dist/flowbite.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.1/datepicker.min.js"></script>
</body>

</html>