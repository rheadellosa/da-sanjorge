<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFarmersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('farmers', function (Blueprint $table) {
            $table->id();
            $table->string('reference_id')->nullable();
            $table->longText('img')->nullable();
            $table->string('qr_code')->nullable();
            $table->string('first_name')->nullable();
            $table->string('middle_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('extension_name')->nullable();
            $table->string('bldg_number')->nullable();
            $table->string('street')->nullable();
            $table->string('barangay')->nullable();
            $table->string('municipality')->nullable();
            $table->string('province')->nullable();
            $table->string('region')->nullable();
            $table->string('contact_number')->nullable();
            $table->string('date_of_birth')->nullable();
            $table->string('place_of_birth')->nullable();
            $table->string('religion')->nullable();
            $table->string('civil_status')->nullable();
            $table->string('spouse_name')->nullable();
            $table->string('mothers_name')->nullable();
            $table->boolean('is_household_head')->default(false);
            $table->string('household_head_name')->nullable();
            $table->string('relationships')->nullable();
            $table->integer('no_household_members')->nullable();
            $table->integer('no_male')->nullable();
            $table->integer('no_female')->nullable();
            $table->string('highest_formal_education')->nullable();
            $table->boolean('is_with_disability')->default(false);
            $table->boolean('is_4ps_beneficiary')->default(false);
            $table->string('indigenous_group_name')->nullable();
            $table->string('government_id_number')->nullable();
            $table->string('farmers_association_name')->nullable();
            $table->string('person_to_notify')->nullable();
            $table->string('category')->nullable();
            $table->timestamps();

            $table->foreignId('brgy_id')->constrained('barangays');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('farmers');
    }
}
