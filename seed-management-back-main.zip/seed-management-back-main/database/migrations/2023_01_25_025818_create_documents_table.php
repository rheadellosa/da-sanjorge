<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDocumentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('documents', function (Blueprint $table) {
            $table->id();
            $table->longText('rsbsa_form')->nullable();
            $table->longText('tax_declaration')->nullable();
            $table->longText('brgy_clearance')->nullable();
            $table->longText('insurance')->nullable();
            $table->longText('valid_ids')->nullable();
            $table->longText('client_satisfaction')->nullable();
            $table->foreignId('farmer_id')->constrained('farmers')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('documents');
    }
}
