<?php

namespace Database\Seeders;

use App\Models\Announcement;
use App\Models\User;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        app()->make(\Spatie\Permission\PermissionRegistrar::class)->forgetCachedPermissions();

        $roles = [
            ['name' => 'admin', 'guard_name' => 'api'],
            ['name' => 'rice officer', 'guard_name' => 'api'],
            ['name' => 'high value crop officer', 'guard_name' => 'api'],
            ['name' => 'corn officer', 'guard_name' => 'api']
        ];


        // $permissions = [
        //     "view_farmers",
        //     "add_farmers",
        //     "edit_farmers",
        //     "delete_farmers",

        //     "view_accounting_rice",
        //     "view_accounting_seed",
        //     "view_accounting_financial",

        //     "view_lands",

        //     "view_barangays",
        //     "add_barangays",
        //     "edit_barangays",
        //     "delete_barangays",

        //     "view_roles",
        //     "add_roles",
        //     "edit_roles",
        //     "delete_roles"
        // ];

        $permissions = [
            "manage_rice_distribution",
            "manage_seed_distribution",
            "manage_corn_distribution",
            "manage_settings",
        ];

        foreach ($roles as $key => $role) {
            Role::create($role);
        }

        // ADMINS AND OFFICERS
        $users = [
            ['first_name' => 'Super', 'last_name' => 'Admin', 'email' => 'admin@gmail.com', 'password' => 'password', 'role' => 'admin'],
            ['first_name' => 'Rice', 'last_name' => 'Officer', 'email' => 'rice@gmail.com', 'password' => 'password', 'role' => 'rice officer'],
            ['first_name' => 'High Value Crop', 'last_name' => 'Officer', 'email' => 'high-value-crop@gmail.com', 'password' => 'password', 'role' => 'high value crop officer'],
            ['first_name' => 'Corn', 'last_name' => 'Officer', 'email' => 'corn@gmail.com', 'password' => 'password', 'role' => 'corn officer'],
        ];
        foreach ($users as $key => $user) {
            $role = $user['role'];
            unset($user['role']);
            $user['password'] = bcrypt($user['password']);
            $newUser = User::create($user);
            $newUser->assignRole($role);
        }


        foreach ($permissions as $key => $permission) {
            Permission::create(['name' => $permission, 'guard_name' => 'api']);
        }

        // assign all permissions to admin
        $admin = Role::where('name', 'admin')->first();
        $admin->syncPermissions($permissions);

        // rice
        $riceOfficer = Role::where('name', 'rice officer')->first();
        $riceOfficer->givePermissionTo('manage_rice_distribution');

        // high value crop
        $cropOfficer = Role::where('name', 'high value crop officer')->first();
        $cropOfficer->givePermissionTo('manage_seed_distribution');

        // corn
        $cornOfficer = Role::where('name', 'corn officer')->first();
        $cornOfficer->givePermissionTo('manage_corn_distribution');

        $this->call([
            BarangaySeeder::class,
            FarmerSeeder::class
        ]);

        // announcements
        $announcements = [
            [
                'title' => "Test Announcement",
                'content' => 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nostrum maiores, cumque harum, ea eum vero ratione accusamus expedita dolorem ullam adipisci esse similique officiis aut sequi laudantium doloribus! Consequuntur, officia cum incidunt necessitatibus iure velit voluptatum. Ad eaque magnam, sequi tempore consequuntur repellendus voluptatem architecto reprehenderit nesciunt nam, sunt ex obcaecati dolore totam pariatur dolorum esse nemo repudiandae nulla vel unde quos consequatur excepturi. Molestias necessitatibus provident odit labore corrupti doloremque voluptates dignissimos vero, nesciunt, eum qui accusamus quibusdam aperiam quam doloribus tempore adipisci ad, eius distinctio voluptate consequuntur asperiores dolore laudantium repellendus! Qui recusandae consectetur eum praesentium officia odio.',
                'user_id' => 1
            ],
            [
                'title' => "Test Announcement",
                'content' => 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nostrum maiores, cumque harum, ea eum vero ratione accusamus expedita dolorem ullam adipisci esse similique officiis aut sequi laudantium doloribus! Consequuntur, officia cum incidunt necessitatibus iure velit voluptatum. Ad eaque magnam, sequi tempore consequuntur repellendus voluptatem architecto reprehenderit nesciunt nam, sunt ex obcaecati dolore totam pariatur dolorum esse nemo repudiandae nulla vel unde quos consequatur excepturi. Molestias necessitatibus provident odit labore corrupti doloremque voluptates dignissimos vero, nesciunt, eum qui accusamus quibusdam aperiam quam doloribus tempore adipisci ad, eius distinctio voluptate consequuntur asperiores dolore laudantium repellendus! Qui recusandae consectetur eum praesentium officia odio.',
                'user_id' => 1
            ],
            [
                'title' => "Test Announcement",
                'content' => 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nostrum maiores, cumque harum, ea eum vero ratione accusamus expedita dolorem ullam adipisci esse similique officiis aut sequi laudantium doloribus! Consequuntur, officia cum incidunt necessitatibus iure velit voluptatum. Ad eaque magnam, sequi tempore consequuntur repellendus voluptatem architecto reprehenderit nesciunt nam, sunt ex obcaecati dolore totam pariatur dolorum esse nemo repudiandae nulla vel unde quos consequatur excepturi. Molestias necessitatibus provident odit labore corrupti doloremque voluptates dignissimos vero, nesciunt, eum qui accusamus quibusdam aperiam quam doloribus tempore adipisci ad, eius distinctio voluptate consequuntur asperiores dolore laudantium repellendus! Qui recusandae consectetur eum praesentium officia odio.',
                'user_id' => 1
            ],
        ];

        foreach ($announcements as $key => $announcement) {
           Announcement::create($announcement);
        }
    }
}
