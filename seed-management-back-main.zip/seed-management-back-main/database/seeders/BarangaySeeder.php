<?php

namespace Database\Seeders;

use App\Models\Barangay;
use Illuminate\Database\Seeder;

class BarangaySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            "Aurora",
            "Blanca Aurora",
            "Buenavista I",
            "Bulao",
            "Bungliw",
            "Cogtoto-og",
            "Calundan",
            "Cantaguic",
            "Canyaki",
            "Erenas",
            "Guadalupe",
            "Hernandez",
            "Himay",
            "Janipon",
            "La Paz",
            "Libertad",
            "Lincoro",
            "Matalud",
            "Mobo-ob",
            "Quezon",
            "Ranera",
            "Rosalim",
            "San Isidro",
            "San Jorge I (Poblacion)",
            "Sapinit",
            "Sinit-an",
            "Tomogbong",
            "Gayondato",
            "Puhagan",
            "Anquiana",
            "Bay-ang",
            "Buenavista II",
            "Cabugao",
            "Cag-olo-olo",
            "Guindapunan",
            "Mabuhay",
            "Mancol (Poblacion)",
            "Mombon",
            "Rawis",
            "San Jorge II (Poblacion)",
            "San Juan",
        ];

        foreach($items as $item) {
            Barangay::create([
                'name' => $item
            ]);
        }
    }
}
