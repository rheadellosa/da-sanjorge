<?php

namespace Database\Factories;

use App\Models\Farmer;
use Illuminate\Database\Eloquent\Factories\Factory;

class FarmerFactory extends Factory
{

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'reference_id' => "08-60-25-03-".$this->faker->randomNumber(5),
            'img' => $this->faker->imageUrl(300, 300, 'user'),
            'qr_code' => $this->faker->countryCode(),
            'first_name' => $this->faker->firstName(),
            'middle_name' => $this->faker->lastName(),
            'last_name' => $this->faker->lastName(),
            'contact_number' => $this->faker->phoneNumber(),
            'brgy_id' => rand(1, 10)
        ];
    }
}
