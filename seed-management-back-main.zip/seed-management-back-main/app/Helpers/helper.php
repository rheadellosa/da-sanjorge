<?php

function generateRandomString($length = 5) {
    $characters = '0123456789';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function imageUploader($file, $path)
{
    $folder = public_path($path);

    if (empty($file)) return '';
    
    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    }
    
    $name = time(). generateRandomString(15) . '.' . explode('/', explode(':', substr($file, 0, strpos($file, ';')))[1])[1];

    $success = Image::make($file)
        ->save($folder.$name, 60);

    if ($success) return $name;
    return null;
}