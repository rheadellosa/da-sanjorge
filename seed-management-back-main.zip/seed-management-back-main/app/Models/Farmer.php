<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Farmer extends Model
{
    use HasFactory;

    protected $fillable = [
        'reference_id',
        'img',
        'qr_code',
        'first_name',
        'middle_name',
        'last_name',
        'extension_name',
        'bldg_number',
        'street',
        'municipality',
        'province',
        'region',
        'contact_number',
        'date_of_birth',
        'place_of_birth',
        'religion',
        'civil_status',
        'mothers_name',
        'is_household_head',
        'household_head_name',
        'relationships',
        'no_household_members',
        'no_male',
        'no_female',
        'highest_formal_education',
        'is_with_disability',
        'is_4ps_beneficiary',
        'indigenous_group_name',
        'government_id_number',
        'farmers_association_name',
        'person_to_notify',
        'brgy_id',
        'category'
    ];


    public function barangay()
    {
        return $this->belongsTo(Barangay::class, 'brgy_id');
    }

    public function lands()
    {
        return $this->hasMany(Land::class);
    }

    public function document()
    {
        return $this->hasOne(Document::class);
    }

    public function distributions()
    {
        return $this->hasMany(Distribution::class);
    }
}
