<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SeedDistribution extends Model
{
    use HasFactory;

    const SEED_TYPE = 1;
    const CORN_TYPE = 2;

    protected $fillable = [
        'seeds',
    ];

    public function distributions()
    {
        return $this->morphMany(Distribution::class, 'distributable');
    }
}
