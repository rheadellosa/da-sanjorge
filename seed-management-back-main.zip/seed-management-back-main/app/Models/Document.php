<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Document extends Model
{
    use HasFactory;

    protected $fillable = [
        'rsbsa_form',
        'tax_declaration',
        'brgy_clearance',
        'insurance',
        'valid_ids',
        'client_satisfaction',
        'farmer_id'
    ];

    public function farmer()
    {
        return $this->belongsTo(Farmer::class);
    }
}
