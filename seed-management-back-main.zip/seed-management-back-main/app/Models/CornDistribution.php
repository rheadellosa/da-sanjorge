<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CornDistribution extends Model
{
    use HasFactory;


    protected $fillable = [
        'name',
        'seeds',
    ];

    public function distributions()
    {
        return $this->morphMany(Distribution::class, 'distributable');
    }
}
