<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Distribution extends Model
{
    use HasFactory;

     /**
     * Get the parent distributable model (post or video).
     */
    public function distributable(): MorphTo
    {
        return $this->morphTo();
    }

    public function farmer()
    {
        return $this->belongsTo(Farmer::class);
    }
}
