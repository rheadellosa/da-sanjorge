<?php

namespace App\Http\Controllers;

use App\Models\Distribution;
use App\Models\RiceDistribution;
use Illuminate\Http\Request;

class RiceDistributionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $query = RiceDistribution::query();

        if (request('search')) {
            $query
                ->where('name', 'like', '%' . request('search') . '%');
        }

        return response()->json($query->with('distributions')->orderBy('created_at', 'desc')->get(), 200);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $distribution = new RiceDistribution();

        $distribution->name = $request->name;
        $distribution->type = $request->type;
        $distribution->distribution_date = $request->distribution_date;

        $distributionInstances = [];
        foreach ($request->distributions as $key => $farmerData) {
            $farmerDistribution = new Distribution();
            $farmerDistribution->farmer_id = $farmerData['farmer']['id'];
            $farmerDistribution->amount = $farmerData['amount'];
            $farmerDistribution->distributable_id = $distribution->id;
            $farmerDistribution->distributable_type = 'App\Models\RiceDistribution';
            array_push($distributionInstances, $farmerDistribution);
        }
        $distribution->save();

        $distribution->distributions()->saveMany($distributionInstances);

        return response()->json($distribution, 200);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $rice = RiceDistribution::with('distributions.farmer.barangay')->findOrFail($id);
        return response()->json($rice, 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $distribution = RiceDistribution::findOrFail($id);

        $distribution->name = $request->name;
        $distribution->type = $request->type;
        $distribution->distribution_date = $request->distribution_date;

        $distributionInstances = [];
        foreach ($request->distributions as $key => $farmerData) {
            if (!isset($farmerData['id'])) {
                $farmerDistribution = new Distribution();
            }else {
                $farmerDistribution = Distribution::findOrFail($farmerData['id']);
            }
            $farmerDistribution->farmer_id = $farmerData['farmer']['id'];
            $farmerDistribution->amount = $farmerData['amount'];
            $farmerDistribution->distributable_id = $distribution->id;
            $farmerDistribution->distributable_type = 'App\Models\RiceDistribution';
            array_push($distributionInstances, $farmerDistribution);
        }
        $distribution->save();

        $distribution->distributions()->saveMany($distributionInstances);

        return response()->json($distribution, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
