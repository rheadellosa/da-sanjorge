<?php

namespace App\Http\Controllers;

use App\Models\CornDistribution;
use App\Models\Distribution;
use Illuminate\Http\Request;

class CornDistributionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $query = CornDistribution::query();

        if (request('search')) {
            $query
                ->where('name', 'like', '%' . request('search') . '%');
        }

        return response()->json($query->with('distributions')->orderBy('created_at', 'desc')->get(), 200);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $distribution = new CornDistribution();
        $distribution->name = $request->name;
        $distribution->seeds = json_encode($request->seeds);

        $distributionInstances = [];
        foreach ($request->farmers as $key => $farmerData) {
            $farmerDistribution = new Distribution();
            $farmerDistribution->farmer_id = $farmerData['farmer']['id'];
            $farmerDistribution->seed = $farmerData['seed'];
            $farmerDistribution->amount = $farmerData['seedQty'];
            $farmerDistribution->unit = $farmerData['seedUnit'];
            $farmerDistribution->distributable_id = $distribution->id;
            $farmerDistribution->distributable_type = 'App\Models\CornDistribution';
            array_push($distributionInstances, $farmerDistribution);
        }

        $distribution->save();

        $distribution->distributions()->saveMany($distributionInstances);

        return response()->json($distribution, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $distribution = CornDistribution::with('distributions.farmer.barangay')->findOrFail($id);
        return response()->json($distribution, 200);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $distribution = CornDistribution::findOrFail($id);
        $distribution->name = $request->name;
        $distribution->seeds = json_encode($request->seeds);

        $distributionInstances = [];
        foreach ($request->farmers as $key => $farmerData) {

            if (!isset($farmerData['id'])) {
                $farmerDistribution = new Distribution();
            } else {
                $farmerDistribution = Distribution::findOrFail($farmerData['id']);
            }

            $farmerDistribution = new Distribution();
            $farmerDistribution->farmer_id = $farmerData['farmer']['id'];
            $farmerDistribution->seed = $farmerData['seed'];
            $farmerDistribution->amount = $farmerData['seedQty'];
            $farmerDistribution->unit = $farmerData['seedUnit'];
            $farmerDistribution->distributable_id = $distribution->id;
            $farmerDistribution->distributable_type = 'App\Models\CornDistribution';
            array_push($distributionInstances, $farmerDistribution);
        }

        $distribution->save();

        $distribution->distributions()->saveMany($distributionInstances);

        return response()->json($distribution, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
