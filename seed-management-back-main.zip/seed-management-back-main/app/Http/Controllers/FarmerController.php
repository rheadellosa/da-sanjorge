<?php

namespace App\Http\Controllers;

use App\Models\Document;
use App\Models\Farmer;
use App\Models\Land;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class FarmerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $query = Farmer::query();

        if (request('search')) {
            $query
                ->where('first_name', 'like', '%' . request('search') . '%')
                ->orWhere('middle_name', 'like', '%' . request('search') . '%')
                ->orWhere('last_name', 'like', '%' . request('search') . '%')
                ->orWhere('reference_id', 'like', '%' . request('search') . '%');
        }

        return response()->json($query->with('barangay', 'lands')->orderBy('created_at', 'desc')->get(), 200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        // $data['reference_id'] = "08-60-25-03-".mt_rand(100000, 999999);
        $data['brgy_id'] = $data['barangay'];

        // generate QR
        if (!file_exists(public_path('images/qr-codes'))) {
            mkdir(public_path('images/qr-codes'), 0770, true);
        }
        QrCode::generate(
            $data['last_name'] . ', ' . $data['first_name'] . ' ' . $data['middle_name'] . ' - ' . $data['reference_id'],
            public_path('images/qr-codes/' . $data['reference_id'] . '.svg')
        );
        $data['qr_code'] = config('app.url') . '/images/qr-codes/' . $data['reference_id'] . '.svg';

        if ($request->hasFile('img')) {
            $data['img'] = $this->saveFiles($request->file('img'), 'images/farmers');
        }

        $farmer = Farmer::create($data);

        // save documents
        $this->saveDocuments($farmer, $request);

        // save lands
        if ($data['lands']) {
            $this->saveLands($farmer, json_decode($data['lands'], true));
        }

        return response()->json($farmer, 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $farmer = Farmer::with('barangay', 'document', 'lands.barangay')->find($id);
        return response()->json($farmer, 200);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->all();
        $data['brgy_id'] = $data['barangay'];

        if ($request->hasFile('img')) {
            $image = $this->saveFiles($request->file('img'), 'images/farmers');
            if ($image) {
                $data['img'] = $image;
            }
        }else {
            unset($data['img']);
        }

        $farmer = Farmer::find($id);
        $farmer->update($data);

        // save documents
        $this->saveDocuments($farmer, $request);

        // save lands
        if ($data['lands']) {
            $this->saveLands($farmer, json_decode($data['lands'], true));
        }

        return response()->json($farmer, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Farmer $farmer)
    {
        $farmer->delete();
        return response()->json('success', 200);
    }

    /**
     * register lands to farmer
     *
     * @param  Farmer    $farmer
     * @param  array  $lands
     */
    private function saveLands($farmer, $lands)
    {
        $lands_without_id = collect($lands)->where('id', '');
        $lands_with_id = (clone collect($lands))->where('id', '!=', '');
        $lands_ids = $lands_with_id->pluck('id');

        foreach ($lands_with_id as $land) {
            $land['farmer_id'] = $farmer->id;
            $obj = Land::find($land['id']);
            $obj->update($land);
        }

        $farmer->lands()->whereNotIn('id', $lands_ids)->delete();

        $lands_without_id->each(function ($land) use ($farmer) {
            $land['farmer_id'] = $farmer->id;
            Land::create($land);
        });
    }

    /**
     * Save file to path
     *
     * @param  File  $file
     * @param  string  $path
     * @return string
     */
    private function saveFiles($file, $path)
    {
        if (!file_exists($path)) {
            mkdir($path, 0777, true);
        }
        $filename = time().rand(3, 9). '.'.$file->getClientOriginalExtension();
        $file->move($path, $filename);

        return '/'.$path.'/'.$filename;
    }


    /**
     * Save documents
     *
     * @param  Farmer  $farmer
     * @param  Request  $request
     */
    private function saveDocuments($farmer, $request)
    {
        Document::updateOrCreate(
            ['farmer_id' => $farmer->id],
            [
                'farmer_id' => $farmer->id,
                'rsbsa_form' => $request->hasFile('rsbsa_form') ? $this->saveFiles($request->rsbsa_form, 'images/documents') : '',
                'tax_declaration' => $request->hasFile('tax_declaration') ? $this->saveFiles($request->tax_declaration, 'images/documents') : '',
                'brgy_clearance' => $request->hasFile('brgy_clearance') ? $this->saveFiles($request->brgy_clearance, 'images/documents') : '',
                'insurance' => $request->hasFile('insurance') ? $this->saveFiles($request->insurance, 'images/documents') : '',
                'valid_ids' => $request->hasFile('valid_ids') ? $this->saveFiles($request->valid_ids, 'images/documents') : '',
                'client_satisfaction' => $request->hasFile('client_satisfaction') ? $this->saveFiles($request->client_satisfaction, 'images/documents') : '',
            ]
        );
    }
}
