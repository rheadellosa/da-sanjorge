<?php

namespace App\Http\Controllers;

use App\Models\Farmer;
use App\Models\Land;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function getAllStats() {
        $total_farmers = Farmer::all()->count();
        $total_lands = Land::all()->count();
        $total_distributions = 6;

        return response()->json([
            'total_farmers' => $total_farmers,
            'total_lands' => $total_lands,
            'total_distributions' => $total_distributions],
        200);

    }
}
