<?php

namespace App\Http\Controllers;

use Throwable;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Laravel\Passport\RefreshToken;
use Laravel\Passport\Token;

class UserController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required',
            'password' => 'required'
        ]);

        $user = User::with('roles')->where('email', $request->email)->first();

        if (!$user) {
            return response()->json(['error' => 'User not found!'], 404);
        }

        if (!Hash::check($request->password, $user->password)) {
            return response()->json(['error' => 'Invalid credentials'], 422);
        }

        $success['token'] =  $user->createToken('web')->accessToken;
        $success['user'] =  $user;

        return response()->json($success, 200);
    }

    public function register(Request $request)
    {
        $input = $request->all();

        $checkUser = User::where('email', $request->email)->first();
        if ($checkUser) {
            return response()->json(['error' => 'User already exist'], 422);
        }

        try {
            DB::beginTransaction();
            $user = new User;
            $user->email = $input['email'];
            $user->password = bcrypt($input['password']);
            $user->save();

            $success['token'] =  $user->createToken('web')->accessToken;
            $success['user'] =  $user;

            DB::commit();
            return response()->json($success, 200);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function getUser()
    {
        $user = User::with('roles.permissions')->find(Auth::user()->id);

        return $user;
    }

    public function logout()
    {
        Auth::user()->tokens->each(function ($token, $key) {
            $token->delete();
        });
        return response(['message' => 'Success'], 200);
    }
}
