<?php

use App\Http\Controllers\AnnouncementController;
use App\Http\Controllers\BarangayController;
use App\Http\Controllers\CornDistributionController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\FarmerController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\LandController;
use App\Http\Controllers\OfficerController;
use App\Http\Controllers\RiceDistributionController;
use App\Http\Controllers\SeedsController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Authentication
Route::controller(UserController::class)->group(function () {
    Route::post('login', 'login');
});

// Announcements
Route::controller(AnnouncementController::class)->group(function () {
    Route::get('announcements', 'getAllAnnouncements');
});


Route::group(['middleware' => 'auth:api'], function () {

    // Dashboard
    Route::controller(DashboardController::class)->group(function () {
        Route::get('dashboard-stats', 'getAllStats');
    });

    // User
    Route::controller(UserController::class)->group(function () {
        Route::post('register', 'register');
        Route::get('user', 'getUser');
        Route::post('logout', 'logout');
    });

    // Farmers
    Route::resource('farmers', FarmerController::class, [
        'except' => ['create', 'edit']
    ]);

    // Barangays
    Route::resource('barangays', BarangayController::class, [
        'except' => ['create', 'edit']
    ]);

    // Lands
    Route::resource('lands', LandController::class, [
        'except' => ['create', 'edit']
    ]);

    // Officers
    Route::controller(OfficerController::class)->group(function () {
        // Roles and Permissions
        Route::get('roles', 'getRoles');
        Route::get('permissions', 'getPermissions');
        Route::post('sync-role-permissions/{id}', 'syncRolePermissions');
    });

    // Officers
    Route::resource('officers', OfficerController::class, [
        'except' => ['create', 'edit']
    ]);

    Route::resource('announcements-admin', AnnouncementController::class, [
        'except' => ['create', 'edit']
    ]);

    // RICE
    Route::resource('rice-distributions', RiceDistributionController::class, [
        'except' => ['create', 'edit']
    ]);

    // SEED
    Route::resource('seed-distributions', SeedsController::class, [
        'except' => ['create', 'edit']
    ]);

    // CORN
    Route::resource('corn-distributions', CornDistributionController::class, [
        'except' => ['create', 'edit']
    ]);
});
